/****************************************************
 *Author: Pierre Saladino
 *Description:  Binary search header
 *************************************************/
#ifndef BINARYSEARCH_HPP
#define BINARYSEARCH_HPP
#include <vector>

int Binarysearch(std::vector<int> const &vectorIn, int target); 

#endif
