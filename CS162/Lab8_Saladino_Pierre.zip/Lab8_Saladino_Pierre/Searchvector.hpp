/****************************************************
 *Author: Pierre Saladino
 *Description: Search header
 *************************************************/
#ifndef SEARCHVECTOR_HPP
#define SEARCHVECTOR_HPP
#include <vector>

int Searchvector(std::vector<int> const &vectorIn, int target); 

#endif
