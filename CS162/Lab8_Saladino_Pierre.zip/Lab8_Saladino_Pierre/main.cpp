/****************************************************
 *Author: Pierre Saladino
 *Description:  main file
 *************************************************/
#include "Searchvector.hpp"
#include "Sortvector.hpp"
#include "Binarysearch.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <limits>

int main()
{
	int TARGET;

	std::vector<int> original,
		beginning,
		middle,
		end,
		originalSorted,
		beginningSorted,
		middleSorted,
		endSorted;

	std::fstream inOutFile;

	int val,	
	    result;	 

	std::string fileName;	

	std::cout << "\n----------------Searching and Sorting ----------------\n\n";
	std::cout << "Enter target Value: "; 
	while (!(std::cin >> TARGET))
	{
	std::cin.clear();
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n'); 
	std::cout << "Invalid target, try again " << std::endl;   
	} 
	
	std::cout << "The target value is: " << TARGET << std::endl;
	std::cout << "----------------------------------------\n";

//opens originatl.txt file
	inOutFile.open("original.txt");
	if(inOutFile.fail())//if file not found
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading original.txt...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		original.push_back(val);//adds val while file open
	}
	
	inOutFile.close();//close file

	std::cout << "\nSearching original.txt file for target value...\n";
	result = Searchvector(original, TARGET);//searches original.txt for target val 

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";//if target not found or return is -1
		std::cout << "---------------------------------------\n\n";
	}
	else
	{	//once target val is found, print location
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";
		std::cout << "---------------------------------------\n\n";

	}

	//for beginning.txt
	inOutFile.open("beginning.txt");
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading beginning.txt...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		beginning.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching beginning.txt file for target value...\n";
	result = Searchvector(beginning, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	
		std::cout << "---------------------------------------\n\n";
	}

	//middle
	inOutFile.open("middle.txt");
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading middle.txt ...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		middle.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching middle.txt for the target value...\n";
	result = Searchvector(middle, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	
		std::cout << "---------------------------------------\n\n";
	}

	//end
	inOutFile.open("end.txt");
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading end.txt...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		end.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching entd.txt for the target value...\n";
	result = Searchvector(end, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	
		std::cout << "---------------------------------------\n\n";
	}


	std::cout << "------------Sort and Binary Search-------------\n\n";
	getline(std::cin, fileName);
	std::cout << "Enter the filename you wish to output the sorted original file to: ";
	getline(std::cin, fileName);//receive file name
	std::cout << "You inputted: " << fileName << std::endl;

	//sort original.txt then print results to file 
	Sortvector(original, fileName);
	fileName.append(".txt");//add .txt to filename from user input
	
	//open filename
	inOutFile.open(fileName);
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading " << fileName << " file...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		originalSorted.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching "<< fileName << " for target value...\n";
	result = Binarysearch(originalSorted, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	 
		std::cout << "---------------------------------------\n\n";

	}

	//beginning
	std::cout << "Enter the filename you wish to output the sorted beginning file to: ";
	getline(std::cin, fileName);
	std::cout << "You inputted: " << fileName << std::endl;

	Sortvector(beginning, fileName);
	fileName.append(".txt");
	
	inOutFile.open(fileName);
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading " << fileName << " file...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		beginningSorted.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching " << fileName << " for target value...\n";
	result = Binarysearch(beginningSorted, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	
		std::cout << "---------------------------------------\n\n";

	}

	//middle
	std::cout << "Enter the filename you wish to output the sorted middle file to: ";
	getline(std::cin, fileName);
	std::cout << "You inputted: " << fileName << std::endl;

	Sortvector(middle, fileName);
	fileName.append(".txt");
	
	inOutFile.open(fileName);
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading " << fileName << " file...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		middleSorted.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching " << fileName << " for target value...\n";
	result = Binarysearch(middleSorted, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";
		std::cout << "---------------------------------------\n\n";

	}

	//end 
	std::cout << "Enter the filename you wish to output the sorted end file to: ";
	getline(std::cin, fileName);
	std::cout << "You inputted: " << fileName << std::endl;

	Sortvector(end, fileName);
	fileName.append(".txt");
	
	inOutFile.open(fileName);
	if(inOutFile.fail())
	{
		std::cout << "The file was not found.";
		return 1;
	}

	std::cout << "Reading " << fileName << " file...\n";
	while(inOutFile >> val)
	{
		std::cout << val << "  ";
		endSorted.push_back(val);
	}
	
	inOutFile.close();

	std::cout << "\nSearching " << fileName << " for target value...\n";
	result = Binarysearch(endSorted, TARGET);

	if(result == -1)
	{
		std::cout << "Target value " << TARGET << " not found\n";
		std::cout << "---------------------------------------\n\n";
	}
	else
	{
		std::cout << "The target value " << TARGET << " is located at position ";
		std::cout << result + 1 << "\n";	
		std::cout << "---------------------------------------\n\n";

	}

	std::cout << "Files have been written, exiting program...\n\n";

	return 0;
}
