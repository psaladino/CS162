/****************************************************
 *Author: Pierre Saladino
 *Description: Search implementation
 *************************************************/
#include "Searchvector.hpp"
//int function. returns position 
int Searchvector(std::vector<int> const &vectorIn, int target)
{
	int index = 0;		
	int position = -1;	
	bool found = false; 	

	while(index < vectorIn.size() && !found)
	{
		if(vectorIn[index] == target)	
		{
			found = true;		
			position = index;	
		}
		index++;			
	}
	return position;			
}
