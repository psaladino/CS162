/****************************************************
 *Author: Pierre Saladino
 *Description: binary search implementation
 *************************************************/
#include "Binarysearch.hpp"
//int function returns position
int Binarysearch(std::vector<int> const &vectorIn, int target)
{
//binary search algorithm from page 607, chapter 9.1, early objects 9th ed. 
	int first = 0,			
	    last = vectorIn.size() - 1,	
	    middle,			
	    position = -1;		

	bool found = false;		

	while(!found && first <= last)
	{
		middle = (first + last) / 2;	
		if(vectorIn[middle] == target)	
		{
			found = true;
			position = middle;
		}
		else if(vectorIn[middle] > target) 
		{
			last = middle -1;
		}
		else 
		{
			first = middle + 1;
		}
	}
	return position;
}
