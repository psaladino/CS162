/****************************************************
 *Author: Pierre Saladino
 *Description: Sort header
 *************************************************/
#ifndef SORTVECTOR_HPP
#define SORTVECTOR_HPP
#include <vector>
#include <string>

void Sortvector(std::vector<int> vectorIn, std::string fileName);

#endif
