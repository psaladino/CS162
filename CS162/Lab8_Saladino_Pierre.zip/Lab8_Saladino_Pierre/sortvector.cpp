/****************************************************
 *Author: Pierre Saladino
 *Description: Sort implementation
 * ************************************************/



#include "Sortvector.hpp"
#include <fstream>
#include <iostream>

void Sortvector(std::vector<int> vectorIn, std::string fileName)
{
	int startScan, minIndex, minValue;
	std::ofstream outputFile;

	//selection sort algorithm page 620 chapter 9, early objects 9th ed.
	//created vectors instead of arrays to call function.  
	for(startScan = 0; startScan < (vectorIn.size() - 1); startScan++)
	{
		minIndex = startScan;
		minValue = vectorIn[startScan];

		for(int index = startScan + 1; index < vectorIn.size(); index++)
		{
			if(vectorIn[index] < minValue)
			{
				minValue = vectorIn[index];
				minIndex = index;
			}
		}
		vectorIn[minIndex] = vectorIn[startScan];
		vectorIn[startScan] = minValue;
	}

	//display sorted vector test
	std::cout << "sorted vector: ";
	for(int val : vectorIn)
	{
		std::cout << val;
	}
	std::cout << std::endl;
	
	//write sorted vector to a text file
	fileName.append(".txt");	//make output file a text file
	outputFile.open(fileName);
	for(int val : vectorIn)
	{
		outputFile << val << '\n';
	}
	outputFile.close();

	std::cout << "Sorted values written to: " << fileName;
	std::cout << std::endl;
	std::cout << "-----------------------------------\n";
}
