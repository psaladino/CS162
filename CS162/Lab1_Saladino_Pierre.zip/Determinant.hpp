/****************
Author: Pierre Saladino
Description: HPP file for determinant function
*************/


#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP
#include "ReadMatrix.hpp"


//header for determinant function
int determinant(int** matrix, int size);

#endif
