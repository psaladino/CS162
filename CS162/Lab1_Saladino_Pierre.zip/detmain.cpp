/****************
Author: Pierre Saladino
Description: main files asks the user for the size of the matrix.
dynamically allocates memory space for matrix using readmatrix to prompt user
to enter 4 or 9 elements of matrix.
calculates the determinant using determinant.
displays both the matrix and the determinant. 
*************/

#include<iostream>
#include<string>
#include"Determinant.hpp"
#include"ReadMatrix.hpp"
#include<cmath>


int main()

{

//variables for matrix, size and determinant
int j, i, size, detr; 

std::cout << "Please enter 2 or 3 for the size of the matrix" << std::endl;
std::cin >> size;

//dynamically allocates memory for matrix
int** arr1;
arr1 = new int* [size];

for (i = 0; i < size; i++)
{
arr1[i] = new int[size];
}    

//calls read matrix to prompt user for matrix elements 
//and display matrix
readMatrix(arr1, size);

// calls determinant function
detr = determinant(arr1, size);

for (i = 0; i < size; i++)
{
 for (j = 0; j < size; j++)
  {  
   std::cout << arr1[i][j] << " ";
  }
  std::cout << std::endl;
}

std::cout << "The determinant of the matrix is " << detr << std::endl;

//deletes the allocated memory
for (i = 0; i < size; i++)
 {
	delete[]arr1[i] ;
 }    
	delete[] arr1;

return 0;
}
