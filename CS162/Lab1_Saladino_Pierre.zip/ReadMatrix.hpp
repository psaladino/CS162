/****************
Author: Pierre Saladino
Description: HPP file for readmatrix function
*************/


#ifndef READMATRIX_HPP
#define READMATRIX_HPP
#include "Determinant.hpp"


//header file for readmatrix function of two parameters
void readMatrix(int** arr1, int size);

#endif

