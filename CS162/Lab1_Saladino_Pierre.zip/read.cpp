/****************
Author: Pierre Saladino
Description: CPP implementation file for readMatrix function.
prompts the user to enter the numbers inside the matrix.
takes a pointer to the 2d array and does not return anything.  
*************/

#include<iostream>
#include<string>
#include<cmath>
#include"ReadMatrix.hpp"

//readMatrix function propmting users for numbers inside the matrix 
void readMatrix(int** arr1, int size)
{
std::cout << "Please enter the " << size * size << " elements for the matrix " << std::endl;

//prompts user to enter an element using a for loop for the total of either 4 or 9 depending on size 
for (int i = 0; i < size; i++)
{ 
 for (int j = 0; j < size; j++)
  { 
	 std::cin >> arr1[i][j];
  }
}

}
 
