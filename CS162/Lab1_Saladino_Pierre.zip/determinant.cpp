/****************
Author: Pierre Saladino
Description: CPP implementation file for determinant function.
This function will have 2 parameters. a pointer to a 2D array and an integer 
the size of the matric 
*************/

#include<iostream>
#include<string>
#include"Determinant.hpp"

//determinant function with two parameters
int determinant(int** matrix, int size)
{
int t1, t2, t3, t4, t5, t6, t7, t8, t9;

//if statement used to calculate the determinant if the size == 2 
if (size == 2) 
 {
int detr = (matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]);

return detr;
 }

//if the size is 3 the determinant is calculated
else if (size == 3)
{
//using variables for matrix positions
t1 = matrix [0][0];
t2 = matrix [0][1];
t3 = matrix [0][2];
t4 = matrix [1][0];
t5 = matrix [1][1];
t6 = matrix [1][2];
t7 = matrix [2][0];
t8 = matrix [2][1];
t9 = matrix [2][2];

//calculating the determinants	
int detA = t1 * ((t5 * t9) - (t6 * t8));
int detB = t2 * ((t4 * t9) - (t6 * t7));
int detC = t3 * ((t4 * t8) - (t5 * t7)); 	

int detr = detA -detB + detC;

return detr;
}

return 0;
}   
