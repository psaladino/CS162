/*********************************************************************
** Author: Pierre Saladino
** Destcription: barbarian implementation file
*********************************************************************/

#include "Creature.hpp"
#include "Barbarian.hpp"
#include <iostream>

//function to intialize stats
Barbarian::Barbarian()
{
armor = 0;
strength = 12;
attackDie = 2;
attackSides = 6;
defenseDie = 2;
defenseSides = 6;
}
//destructotr
Barbarian::~Barbarian()
{
}
