/*********************************************************************
** Author: Pierre Saladino
** Destcription: implementation for medusa class
*********************************************************************/

#include "Creature.hpp"
#include "Medusa.hpp"
#include <iostream>

//constructor intializing stats
Medusa::Medusa()
{
armor = 3;
strength = 8;
attackDie = 2;//glare ability
attackSides = 6;
defenseDie = 1;
defenseSides = 6;
}

//attack function implmenting glare, returns attack 
int Medusa::attack()
{

int attackRoll;

attackRoll = roll(attackDie, attackSides);
std::cout << "Attack roll: " << attackRoll << std::endl;
	
//if attack is 12 turn opponent to stone 
if(attackRoll == 12)
	{
	attackRoll = 421;
	std::cout << "Medusa's glare turns the opponent\n";
	std::cout << "to stone!\n";
	}

	return attackRoll;
}

//destructor
Medusa::~Medusa()
{
}
