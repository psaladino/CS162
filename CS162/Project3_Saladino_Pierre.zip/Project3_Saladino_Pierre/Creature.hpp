/*********************************************************************
** Author: Pierre Saladino
** Destcription: creature class to be inherited by other classes 
*********************************************************************/

#ifndef CREATURE_HPP
#define CREATURE_HPP

class Creature
{
protected:
int armor,
strength,
attackDie,
attackSides,
defenseDie,
defenseSides;

public:
virtual int attack();
virtual void defense(int attack);
int roll(int numDie, int sidesDie);
int getStrength();
int getArmor();
virtual ~Creature() = 0;
};
#endif
