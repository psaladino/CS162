/*********************************************************************
** Author: Pierre Saladino
** Destcription: harrypotter class
*********************************************************************/

#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP
#include "Creature.hpp" //parent class

class HarryPotter : public Creature
{
private:
int revive;
public:
HarryPotter();
virtual void defense(int attackDamage) override; 
virtual ~HarryPotter();
};
#endif
