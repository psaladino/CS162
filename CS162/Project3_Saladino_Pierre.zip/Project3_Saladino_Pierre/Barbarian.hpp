/*********************************************************************
** Author: Pierre Saladino
** Destcription: barbarian class 
*********************************************************************/

#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP
#include "Creature.hpp" //parent class

class Barbarian : public Creature
{
public:
Barbarian();
virtual ~Barbarian();
};
#endif
