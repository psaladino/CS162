 /*********************************************************************
** Author: Pierre Saladino
** Destcription: implementation file for harrypotter class
*********************************************************************/
#include "Creature.hpp"
#include "Harrypotter.hpp"
#include <iostream>

//constructor intializing stats
HarryPotter::HarryPotter()
{
armor = 0;
strength = 10;
attackDie = 2;
attackSides = 6;
defenseDie = 2;
defenseSides = 6;
revive = 1; //if glared by medusa
}

//defense function for harry 
void HarryPotter::defense(int attack)
{

int defenseRoll,damage;

defenseRoll = roll(defenseDie, defenseSides);
std::cout << "Defense roll: " << defenseRoll << std::endl;
	
damage = (attack - defenseRoll - armor);

std::cout << "Attack damage = attack - defenseRoll - armor\n";
std::cout << damage << " = " << attack << " - " << defenseRoll;
std::cout << " - " << armor << std::endl;
	
	
	if(damage > 0)
	{

	
	std::cout << "Defending fighter's strength before attack: " << strength;
	std::cout << std::endl;
	std::cout << "Strength - damage\n";

	strength -= damage;

	std::cout << strength << " - " << damage << " = ";
	std::cout << strength;
	std::cout << "\nDefending fighter's strength after attack: " << strength;
	std::cout << std::endl;

		if(strength <= 0 && revive == 1)
		{
			std::cout << "Harry's revived with double the strength!";
			strength = 20;
			revive--;//decrement revive
		}
	}
	else{
		std::cout << "No damage inflicted!\n";
	}
}

//destructor
HarryPotter::~HarryPotter()
{
}
