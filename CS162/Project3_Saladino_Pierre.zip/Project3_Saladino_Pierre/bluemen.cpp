/*********************************************************************
** Author: Pierre Saladino
** Destcription: implementation for bluemen class
*********************************************************************/

#include "Creature.hpp"
#include "Bluemen.hpp"
#include <iostream>

//constructor intializing stats
BlueMen::BlueMen()
{
armor = 3;
strength = 12;//uses mob 
attackDie = 2;
attackSides = 10;
defenseDie = 3;
defenseSides = 6;
}

//defense function for bluemen, uses mob ability
void BlueMen::defense(int attack)
{

int defenseRoll, damage;

defenseRoll = roll(defenseDie, defenseSides);
std::cout << "Defense roll: " << defenseRoll << std::endl;


damage = (attack - defenseRoll - armor);

std::cout << "Attack damage = attack - defenseRoll - armor\n";
std::cout << damage << " = " << attack << " - " << defenseRoll;
std::cout << " - " << armor << std::endl;
	

	if(damage > 0)
	{

		std::cout << "Defending fighter's strength before attack: " << strength;
		std::cout << std::endl;
		std::cout << "Strength - damage\n";


		strength -= damage;


		std::cout << strength << " - " << damage << " = ";
		std::cout << strength;
		std::cout << "\nDefending fighter's strength after attack: " << strength;
		std::cout << std::endl;

	
		if(strength <= 4){
			defenseDie = 1;
			std::cout << "There is only " << defenseDie;
			std::cout << " Blue Man left.\n";
		}else if(strength <= 8){
			defenseDie = 2;
			std::cout << "Blue men are mourning their fallen friend!\n";
			std::cout << "There are " << defenseDie; 
			std::cout << " left.\n";
		}else{
			defenseDie = 3;
			std::cout << "Blue Men mob is " << defenseDie;
			std::cout << " strong!\n";
		}
	}
	else{
		std::cout << "No damage inflicted!\n";
	}
}

//destructor
BlueMen::~BlueMen()
{
}
