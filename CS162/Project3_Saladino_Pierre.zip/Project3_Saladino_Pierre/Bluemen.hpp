/*********************************************************************
** Author: Pierre Saladino
** Destcription: bluemen class
*********************************************************************/

#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP
#include "Creature.hpp" //parent class

class BlueMen : public Creature
{
public:
BlueMen();
virtual void defense(int attack) override; 
virtual ~BlueMen();
};
#endif
