/*********************************************************************
** Author: Pierre Saladino
** Destcription: game implementation file 
*********************************************************************/
#include "Game.hpp"
#include "Barbarian.hpp"
#include "Vampire.hpp"
#include "Bluemen.hpp"
#include "Medusa.hpp"
#include "Harrypotter.hpp"
#include <iostream>
#include <limits> 
#include <cstdlib>

//starts game and asks for user input
Game::Game()
{

	int fighter1,
	    fighter2;
	bool endProgram = false;

	std::cout << "Select Fighter 1\n";
	fighter1 = getChoice();

	std::cout << "Select Fighter 2\n";
	fighter2 = getChoice();

	switch(fighter1)
	{
		case 1:
			c1 = new Vampire();
			break;
		case 2:
			c1 = new Barbarian();
			break;
		case 3:
			c1 = new BlueMen();
			break;
		case 4:
			c1 = new Medusa();
			break;
		case 5:
			c1 = new HarryPotter();
			break;
		case 6:
			std::cout << "Goodbye\n";
			endProgram = true;
			break;
		default:
			std::cout << "Invalid choice\n";
			endProgram = true;
			break;
	}

	//if program ends
	if(endProgram){
		fighter2 = 6;
	}

	switch(fighter2){
		case 1:
			c2 = new Vampire();
			break;
		case 2:
			c2 = new Barbarian();
			break;
		case 3:
			c2 = new BlueMen();
			break;
		case 4:
			c2 = new Medusa();
			break;
		case 5:
			c2 = new HarryPotter();
			break;
		case 6:
			std::cout << "Goodbye\n";
			endProgram = true;
			break;
		default:
			std::cout << "Invalid choice\n";
			endProgram = true;
			break;
	}

	if(!endProgram)
	{
	//call fight function
	fight(c1, c2);
	}

	//delete new fighters allocated
	delete c1;
	c1 = NULL;
	delete c2;
	c2 = NULL;
	

}

//getchoice function, validate choice. return choice  
int Game::getChoice()
{
int fighterChoice;

	do{
		std::cout << "----- Choose Your Fighters! -----\n";
		std::cout << "Please enter a valid menu option\n";
		std::cout << "1) Vampire\n";
		std::cout << "2) Barbarian\n";
		std::cout << "3) Blue Men\n";
		std::cout << "4) Medusa\n";
		std::cout << "5) Harry Potter\n";
		std::cout << "6) Exit the program\n";

		while(!(std::cin >> fighterChoice))
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid choice\n";
			std::cout << "----- Choose Your Fighters! -----\n";
			std::cout << "Please enter a valid menu option\n";
			std::cout << "1) Vampire\n";
			std::cout << "2) Barbarian\n";
			std::cout << "4) Medusa\n";
			std::cout << "5) Harry Potter\n";
			std::cout << "6) Exit the program\n";
		}

	  }
	while(fighterChoice < 1 || fighterChoice > 6);
	return fighterChoice;
}

//intiate fight function
void Game::fight(Creature* fighter1, Creature* fighter2){
	
	//determine first move from rand function 
	firstStrike = (rand() % 2 + 1);
	std::cout << "Fighter " << firstStrike << " will attack first\n";

	do{
		switch(firstStrike)
		{
			case 1:
				std::cout << "Fighter 1 attacks!\n";
				fighter2->defense(fighter1->attack());
				std::cout << "Round: " << round++;
				std::cout << " results: ";

				if(fighter2->getStrength() <= 0)
				{
					std::cout << "Fighter 1 wins!\n";
					stillStanding = false;
				}
				else{
					std::cout << "The fight continues!\n";
					std::cout << std::endl;
				}
			case 2:
				if(stillStanding == false)
				{
					break;
				}

				std::cout << "Fighter 2 attacks!\n";
				fighter1->defense(fighter2->attack());
				std::cout << "Round: " << round++;
				std::cout << " results: ";

				
				if(fighter1->getStrength() <= 0)
				{
					std::cout << "Fighter 2 wins!\n";
					stillStanding = false;
				}
				else
				{
					std::cout << "The brawl continues...\n";
					std::cout << std::endl;
				}
				firstStrike = 1;
		}
	}

	while(stillStanding); //continue fighting until one fighter is eliminated
}
