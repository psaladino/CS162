/*********************************************************************
** Author: Pierre Saladino
** Destcription: medusa class
*********************************************************************/

#ifndef MEDUSA_HPP
#define MEDUSA_HPP
#include "Creature.hpp" //parent class

class Medusa : public Creature
{
public:
Medusa();
virtual int attack() override; 
virtual ~Medusa();
};
#endif
