/*********************************************************************
** Author: Pierre Saladino
** Destcription: main executable file 
*********************************************************************/
#include "Game.hpp"
#include <ctime> 
#include <cstdlib> 
#include <iostream>

int main()
{

unsigned seed;
seed = time(0);
srand(seed);
	
Game newGame;//create new game
std::cout << "\nGame over\n";
return 0;
}
