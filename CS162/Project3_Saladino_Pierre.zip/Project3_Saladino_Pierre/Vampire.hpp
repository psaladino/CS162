/*********************************************************************
** Author: Pierre Saladino
** Destcription: vampire class using parent class creature
*********************************************************************/

#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP
#include "Creature.hpp" //parent class

class Vampire : public Creature
{
public:
Vampire();
virtual void defense(int attack) override; 
virtual ~Vampire();
};
#endif
