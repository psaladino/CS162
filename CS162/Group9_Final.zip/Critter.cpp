/**************************************************************************************************
 * Program:			Group Project 
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Critter class member function implementation file.	
 **************************************************************************************************/

#include "Critter.hpp"

/**************************************************
 * Critter class two parameter constructor
 **************************************************/
Critter::Critter()
{
	type 	= 	' '; 
	didMove	=	true;	
	age	=	0;
}

/************************************************************************************************
 * Helper Function returns bool type. This function takes in the types of the surroundingspaces from
 * checkboard and checks random locations to find an open one (for use by breed).  It then sets the newX
 * and newY variable if it finds one and returns true, else it returns false.
 **************************************************************************************************/

bool Critter::chooseBreedLoc(char* adjacent)
{
	bool breedFlag = false;
	bool checkedFlag = false;
	bool checked[4] = {false, false, false, false};

	//Havent found a valid breeding spot or checked all possibilities
	while( !breedFlag && !checkedFlag) 
	{
		//Check a random location
		int randomdirection = rand() % 4;
	
		switch(randomdirection)
		{
			//Checking up
			case 0: 
			{
				
				if(*adjacent == ' ')
				{
					
					newX = x - 1;
					newY = y;
					breedFlag = true;
				}
				else
				{
					checked[0] = true;
				}
				
				break;
			}
			
			//Checking right
			case 1:
			{
			
				if(*(adjacent+1) == ' ')
				{
					newX = x;
					newY = y + 1;
					breedFlag = true;
				}
				else
				{
					checked[1] = true;
				}
				break;
			}
			
			//Checking down
			case 2: 
			{
				
				if(*(adjacent+2) == ' ')
				{
					
					newX = x + 1;
					newY = y;
					breedFlag = true;
				}
				else
				{
					checked[2] = true;
				}
				
				break;
			}
			
			//Checking left
			case 3:
			{
				
				if(*(adjacent+3) == ' ')
				{
					newX = x;
					newY = y - 1;
					breedFlag = true;
				}
				else
				{
					checked[3] = true;
				}
				break;
			}
				
		}
		//see if all have been checked
		checkedFlag = (checked[0] && checked[1] && checked[2] && checked[3]);

	}

	

	return breedFlag;
}

/************************************************************************************************
 * Function returns char type. This is used for both printing output and checking spaces for type. 
 **************************************************************************************************/
char Critter::getType()
{
	return type;
}

/**************************************************
 * Function returns true member variable moved
 **************************************************/
bool Critter::moved()
{
	return didMove;
}

/***********************************************
 * Function sets moved variable
 **********************************************/ 
void Critter::setMoved(bool input)
{
	didMove = input;
}

/**************************************************
 * Functions return new location for Critter based on
 * breed or move actions
 **************************************************/
int Critter::getX()
{
	return x;
}
int Critter::getY()
{
	return y;
}
int Critter::getNewX()
{
	return newX;
}
int Critter::getNewY()
{
	return newY;
}
