/**************************************************************************************************
 * Program:			Group Project 
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Doodlebug class header file.	
 **************************************************************************************************/

#ifndef DOODLEBUG_HPP
#define DOODLEBUG_HPP
#include "Critter.hpp"

class Doodlebug : public	Critter
{
	private:
		//by default set to 3 on creation for new object, decrements each turn
		int	belly; 
	
	public:
		//parameters x, y. Used for newly born Doodlebugs
		Doodlebug();
		//parameters x, y, age and belly. Used to create Doodlebugs who already have been living
		Doodlebug(int, int, int, int);
		virtual bool breed(char*);
		virtual bool move(char*, Critter***, int, int);
		void eat(bool); 
		//returns belly variable
		virtual int	getBelly();
};
#endif	




 
