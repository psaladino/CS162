#include <iostream>
#include "Critter.hpp"
#include "Ant.hpp"
#include "Doodlebug.hpp"
#include <string>
#include <ctime>
#include <cstdlib>
#include "game.hpp"
#include "menu.hpp"

using std::cout;
using std::cin;
using std::endl;
int main()
{
	srand(time(NULL));
	// Continues loop until false
	bool playAgain = true;			
	
	//do
	//{
		cout << endl << endl << endl;
		cout << "\t\tPredators vs Prey	" << endl;
		cout << "_________________________________________________" << endl;

		cout << "\t\t***EXTRA CREDIT***" << endl;
		cout << "Asks user for the number of rows, columns, ants and doodlebugs." << endl;
		cout << endl;

		//get info  for extra credit
		int rows = getRows(),
		columns = getColumns(),
		doodlebugs = getDoodlebugs(rows * columns),
		ants = getAnts(rows * columns, doodlebugs);
		// Creates the board
		Critter*** board = createBoard(rows, columns);
		
		// Initialize member variables with their x, y locations
		initializeBoard(board, rows, columns);		
		// Fills board with Doodlebugs	
		fillWithDoodlebugs(board, rows, columns, doodlebugs);
			
		// Fills board with ants
		fillWithAnts(board, rows, columns, ants);
		// Prints the board with ants and doodlebugs
		printBoard(board, rows, columns);

	do
	{	
		// get how many steps they would like to complete
		int stepsToDo = intSelection("How many steps would you like to run through?");
		for (int i = 0; i < stepsToDo; i++)
		{
			//Set moved to false
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					board[i][j]->setMoved(false);
					if (board[i][j]->getType() == ' ')
					{
						//Spaces don't move
						board[i][j]->setMoved(true); 
					}
				}
			}	
			//Doodlebug moves and possibly eats 
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					//if doodlebug has not moved this turn
					if ((board[i][j]->moved() == false) && (board[i][j]->getType() == 'X'))
					{
						//Find an open space
						char*	adjacent = checkBoard(board, i, j, rows, columns);
						if (board[i][j]->move(adjacent, board, i, j))	
						{
							//The doodlebug moves
						}
						
						//no open spaces so did not move
						else 
						{
							board[i][j]->setMoved(true);	
						}
						delete adjacent;
					}
					
					//This doodlebug had already moved this turn, so we move on
					else 
					{
					}
				}
			}	
			//Ant moves 
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					//if ant has not moved this turn
					if ((board[i][j]->moved() == false) && (board[i][j]->getType() == 'O'))
					{
						//Find an open space
						char*	adjacent = checkBoard(board, i, j, rows, columns);
						if (board[i][j]->move(adjacent, board, i, j))	
						{
							//The ant moves 
						}
						
						//no open spaces
						else
						{
							board[i][j]->setMoved(true);	
						}
						delete adjacent;
					}
					
					//This Ant had already moved this turn, so we move on
					else
					{
					}
				}
			}	
			//Breed
			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					char*	adjacent = checkBoard(board, i, j, rows, columns);
					
					//If the critter was old enough, then it breeds
					if (board[i][j]->breed(adjacent))
					{
						int newX = board[i][j]->getNewX();
						int newY = board[i][j]->getNewY(); 
						char type = board[i][j]->getType();
						if (type == 'X')
						{
							delete board[newX][newY];
							Critter *doodlebug = new Doodlebug(newX, newY, 0, 3);
							board[newX][newY] = doodlebug;
						}
						
					 	if (type == 'O')
						{
							delete board[newX][newY];
							Critter *ant = new Ant(newX, newY, 0);
							board[newX][newY] = ant;
					
						}
					}	
					else
					{
						//no breeding
					}
					delete adjacent;
				}
			}	
			
		
		//Print board
		printBoard(board, rows, columns);	
		
		//If the critter is a doodlebug and it has not eaten for three time steps, then it starves
		for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < columns; j++)
				{
					//Is it a doodlebug?
					if (board[i][j]->getType() == 'X')
					{
						//Is that doodlebugs belly empty?
						if (board[i][j]->getBelly() ==  0)
						{
							Critter* critter = new Critter;
							//The doodlebug dies
							delete board[i][j];
							//His spot is now an empty space
							board[i][j] = critter;
						}
					}
				}
			}	
			

		}

			
	
		//Asking the user if they want to play again
		int choice = replayChoice();
		if(choice == 1)
		{
			playAgain = true;
		}

		else
		{
			playAgain = false;
		}

	}while(playAgain == true);

	// free up memory
	destoryBoard(board, rows, columns);
	
	cout << "Goodbye, Thank you for playing Predators vs Prey!" << endl;
	cout << endl;	

	return 0;
}
