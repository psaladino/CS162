/************************************************************************************************
 * Program:			Group Project
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik stone
 * Date:			2/6/2019
 * Description:		Code implementation file for the game header file. This file contains the 
 * 					programs used to create and populate the board with critter objects.
 ***********************************************************************************************/

#include <iostream>
#include "game.hpp"
#include "Critter.hpp"
#include "Ant.hpp"
#include "Doodlebug.hpp"
#include "menu.hpp"
#include <string>
#include <ctime>
#include <cstdlib>

//Get row, column size and number of Ants, Doodlebugs 
int	getRows()
{
	return intSelection("Enter the size of the game grid.\nRows: ",1,100000);
}

int getColumns()
{
	return intSelection("Enter the size of the game grid.\nColumns: ",1,100000);
}


int getDoodlebugs(int boardSize)
{
	return intSelection("How many Doodlebugs populate your board? ", 0, boardSize);
}

int	getAnts(int boardSize, int doodlebugs)
{
	return intSelection("How many Ants populate your board? ", 0, boardSize - doodlebugs);
}

//Create dynamic 2d array of 20*20 Critter pointers
Critter*** createBoard(int rows, int columns)
{
	Critter***	board = new Critter**[rows];
	for (int i = 0; i < rows; i++)
	{
		board[i] = new Critter*[columns];
	}
	return board;
}


//Initialize member variables with their x, y locations
void initializeBoard(Critter*** board, int rowSize, int columnSize)
{
	for (int x = 0; x < rowSize; x++)
	{
		for (int y = 0; y < columnSize; y++)
		{
			board[x][y] = new Critter;
			board[x][y]->setxy(x, y);

		}
	}
}

//Checks adjacent spaces and returns the types of the adjacent cells ('B' for border)
char* checkBoard(Critter*** board, int x, int y, int rowSize, int columnSize)
{
	
	char* adjacent = new char[4];

	//check up
	if(x-1 < 0 )
	{
		adjacent[0] = 'B';
	}
	else
	{
		adjacent[0] = board[x-1][y]->getType();
	}
	//check Right
	if(y+1 >= columnSize )
	{
		adjacent[1] = 'B';
	}
	else
	{
		adjacent[1] = board[x][y+1]->getType();
	}

	//check Down
	if(x+1 >= rowSize )
	{
		adjacent[2] = 'B';
	}
	else
	{
		adjacent[2] = board[x+1][y]->getType();
	}

	//check Left
	if(y-1 < 0 )
	{
		adjacent[3] = 'B';
	}
	else
	{
		adjacent[3] = board[x][y-1]->getType();
	}
	
		
	return adjacent;
}

//Function to place an ant in a space, overwriting the previous
void placeAnt(Critter*** board, int x, int y, int age)
{
	delete board[x][y];
	Critter *ant = new Ant(x,y,age);
	board[x][y] = ant;
}         

//Function to place a doodlebug in a space, overwriting the previous
void placeDoodlebug(Critter*** board, int x, int y, int age, int belly)
{
	delete board[x][y];
	Critter *doodlebug = new Doodlebug(x,y,age,3);
	board[x][y] = doodlebug;
}         

//Print board for testing purposes
void printBoard(Critter*** board, int rowSize, int columnSize)
{
	std::cout << std::endl;
	for (int x = 0; x < rowSize; x++)
	{
		for (int i = 0; i < columnSize; i++)
		{
			std::cout << "+-";
		}
			std::cout << "+\n";		

		for (int y = 0; y < columnSize; y++)
		{
			std::cout << "|" << board[x][y]->getType();
		}

		std::cout << "|" << std::endl;
	}
	for (int i = 0; i < columnSize; i++)
	{
		std::cout << "+-";
	}
		std::cout << "+\n";		

}


//Fill board with 5 randomly placed Doodlebugs
void fillWithDoodlebugs(Critter*** board, int rowSize, int columnSize, int doodlebugNumber)
{
	int initializeD = doodlebugNumber;
	while (initializeD > 0)
	{
		int randomX = rand() % rowSize + 1;
		int	randomY = rand() % columnSize + 1;
		if (board[randomX - 1][randomY - 1]->getType() != 'X')
		{
			delete board[randomX - 1][randomY - 1];  
			Critter *doodlebug = new Doodlebug(randomX-1, randomY-1, 0, 3);
			board[randomX - 1][randomY - 1] = doodlebug;
			initializeD = initializeD - 1;
		}
	}
}


//Fill board with 100 randomly placed Ants 
void fillWithAnts(Critter*** board, int rowSize, int columnSize, int antNumber)
{
	int initializeA = antNumber;
	while (initializeA > 0)
	{
		int randomX = rand() % rowSize + 1;
		int randomY = rand() % columnSize + 1;
		if ((board[randomX - 1][randomY - 1]->getType() != 'X') && (board[randomX - 1][randomY - 1]->getType() != 'O'))
		{
			delete board[randomX - 1][randomY - 1]; 
			Critter *ant = new Ant(randomX-1, randomY-1, 0);
			board[randomX - 1][randomY - 1] = ant;
			initializeA = initializeA - 1;
		}
	}
}


//Deallocate memory
void destoryBoard(Critter*** board, int rowSize, int columnSize)
{
	for (int i = 0; i < rowSize; i++)
	{
		for (int j = 0; j < columnSize; j++)
		{
			delete board[i][j];
		}
	}
	

	for (int i = 0; i < rowSize; i++)
	{
		delete [] board[i];
	}

	
	delete [] board;	

} 
