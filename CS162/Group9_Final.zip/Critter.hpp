/**************************************************************************************************
 * Program:			Group Project 
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Critter class header file.	
 **************************************************************************************************/

#ifndef CRITTER_HPP
#define CRITTER_HPP
#include <iostream>

class Critter
{
	protected:
		//Critter location in rows and columns
		int	x, 
			y, 
			newX,
			newY;	
		//assigns a ' ', X, or O character as a means to identify Critter types when printing
		char type;	
		//keeps track of age for breeding purposes
		int	age;
		//holds whether a Critter has moved that turn
		bool didMove; 
	
	public:
		Critter();	
		void setxy(int row, int column)
		{
			x = row;
			y = column;
		}	
		char getType();
		bool moved();
		int	getX();
		int	getY();
		int	getNewX();
		int	getNewY();
		virtual bool move(char*, Critter***, int, int){};
		virtual bool breed(char*){};
		virtual int	getBelly(){};
		//Helper function to pick a random available spot.
		bool chooseBreedLoc(char*); 
		//resets the critters new location variable to the old location.
		void reset()
		{
			newX = x;
			newY = y;
		}
		void setMoved(bool);
			 
};
#endif	
