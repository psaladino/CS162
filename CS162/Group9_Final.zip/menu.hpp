/******************************************************************************* 
** Author: Erik Stone
** Date: 2019-01-14
** Description: Specification of the Menu function.   The menu class generates
**              a generic menu structure based on an array of strings.  It 
**              is intentionally written to be easily adaptable to other uses.
*******************************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <string>
using std::string;


//Function Prototypes
//Generic input handler
int intSelection(string);
double doubleSelection(string);

//Generic input handler with bounds
int intSelection(string, int, int);
double doubleSelection(string,double,double);

//Helper to Check the input.
bool handleChoice(int&, int, int);
bool handleChoice(double&,double,double);

//helpers for error checking
bool isIntString(string);

//Function asks user whether they want to replay the program
int replayChoice();

#endif



