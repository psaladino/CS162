/******************************************************************************* 
** Author: Erik Stone
** Date: 2019-01-14
** Description: Implementation of the Menu function.   The menu function generates
**              a generic menu structure based on the constructor info.  It 
**              is intentionally written to be easily adaptable to other uses.
*******************************************************************************/

#include "menu.hpp"
#include <climits>
#include <cfloat>
#include <iostream>
#include <string>
#include <limits>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::numeric_limits;


/********************************************************************* 
** Description: Integer Input handlers (with and without bounds)
*********************************************************************/

//Generic integer input handler without Bounds
int intSelection(string header)
{
    //Loop through the menu to get the users choice
    int selection;
    do
    {   
        //Show the selection prompt
        cout << header << endl;
        
    }   
    while(!handleChoice(selection,INT_MIN,INT_MAX));
       
    return selection;
}

//Generic input handler with Bounds
int intSelection(string header, int lowerBound, int upperBound)
{
    //Loop through the menu to get the users choice
    int selection;
    do
    {   
        //Show the selection prompt
        cout << header << endl;
        
    }   
    while(!handleChoice(selection,lowerBound,upperBound));
       
    return selection;
}

/********************************************************************* 
** Description: Double Input handlers (with and without bounds)
*********************************************************************/

//Generic double input handler without Bounds
double doubleSelection(string header)
{
    //Loop through the menu to get the users choice
    double selection;
    do
    {   
        //Show the selection prompt
        cout << header << endl;
        
    }   
    while(!handleChoice(selection,DBL_MIN,DBL_MAX));
       
    return selection;
}

//Generic input handler with Bounds
double doubleSelection(string header, double lowerBound, double upperBound)
{
    //Loop through the menu to get the users choice
   double selection;
    do
    {   
        //Show the selection prompt
        cout << header << endl;
        
    }   
    while(!handleChoice(selection,lowerBound,upperBound));
       
    return selection;
}


/********************************************************************* 
** Description: The handleChoice function ensures the user inputs a valid
**              entry.  I will check for valid type and range and return true
**              if valid and false if not. 
*********************************************************************/

//Handler for Ints
bool handleChoice(int &valToSet, int lowerBound, int upperBound)
{
    string inputString;
    int testVal;

    //Get input from user
    getline(cin,inputString);

    //First Check for Invalid Entry
    if(!isIntString(inputString))
    {
        cout << "Entry is not an integer." << endl;
        return false;
    }  
    else
    {
        testVal = std::stoi(inputString);
    }

    //Now check for bounds
    if ((testVal < lowerBound) || (testVal > upperBound))
    {
        cout << "Entry is out of bounds. Limits are between " << lowerBound << " and " << upperBound << endl;
        return false;
    }
    else
    {
        //Set value & return success
        valToSet = testVal;
        return true;
    }
   
        
}

//Handler for Doubles
bool handleChoice(double &valToSet, double lowerBound, double upperBound)
{
    
    
    //get user input
    double cinVal;
    cin >> cinVal;
    
    //Check for bad input and clear
    //https://stackoverflow.com/questions/1283302/user-input-of-integers-error-handling used as sample of error handling for cin.    
    if (cin.fail())
        {
        cin.clear();
        cin.ignore(INT_MAX,'\n');
        cout << "Entry is not a double." << endl;
        return false;
        }
    else if ((cinVal < lowerBound) || (cinVal > upperBound))
    {
        cin.clear();
        cin.ignore(INT_MAX,'\n');
        cout << "Entry is out of bounds. Limits are between " << lowerBound << " and " << upperBound << endl;
        return false;
    }
    else 
    {
       //Set the choice picked by the user.
       valToSet = cinVal;
       
       //Clear buffer to avoid accidentally re-choosing
       cin.ignore(INT_MAX,'\n');
       
       return true;
    }
      
        
}

//helpers for error checking
bool isIntString(string input)
{
    bool flag = true;

    //read each char (dont care about EOF so size -1)
    for (int i = 0; i < input.size(); i++)
    {
        
        //first value allows negative
        if(i==0 && (input[i]!='-' && (input[i] < 48 || input[i] > 57)))
        {
            flag = false;
        }
            
        else if (i > 0 && (input[i] < 48 || input[i] > 57))
        {
            flag = false;
        } 

    }
        
    //check for non int values
    return flag;
}

//Asks the user if they want to replay the program 
int replayChoice()
{
	int choice;

	cout << "Do you want to run the simulation again?" << endl;
	//Validation loop 
	do
	{
		cout << "Please select the number next to your choice: " << endl;
		cout << "1. Replay" << endl;
		cout << "2. Exit" << endl;
		cin >> choice;
		cin.clear();
		cin.ignore(numeric_limits<int>::max(), '\n');
		cout << endl;

	}while((cin.fail()) || (choice != 1 && choice != 2));

	return choice;
}



