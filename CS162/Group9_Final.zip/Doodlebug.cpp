/**************************************************************************************************
 * Program:			Group Project 
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Doodlebug class member function implementation file.	
 **************************************************************************************************/

#include "Doodlebug.hpp"
#include <ctime>
#include <cstdlib>
#include <iostream>

enum 	Direction {UP , RIGHT, DOWN, LEFT};

/*******************************************************
 * Constructor for newly born Doodlebugs - require only x , y
 *******************************************************/
Doodlebug::Doodlebug()
{
	type = 'X';
	belly = 3;
}
 
/******************************************************
 * Constructor used to create Doodlebug who continue to exist
 ******************************************************/
Doodlebug::Doodlebug(int x, int y, int age, int belly)
{
	type = 'X';
	this->x = x;
	this->y = y;
	this->age = age;
	this->belly = belly;
	newX = x;
	newY = y;
}

/**************************************************
 * Function breeds an Doodlebug under the right conditions
 **************************************************/
bool Doodlebug::breed(char* adjacent)
{
	
	bool breedFlag = false;

	//Try to find an open spot if ant old enough.
	if( age>=8)
		breedFlag = chooseBreedLoc(adjacent);
	
	return breedFlag;
	
}

/**************************************************
 * Function controls Doodlebug movement
 **************************************************/
bool Doodlebug::move(char* grid, Critter*** board, int x, int y)
{
	//If there is an ant in an adjacent square, eat it
	if ((grid[0] == 'O') || (grid[1] == 'O') || (grid[2] == 'O') || (grid[3] == 'O'))
	{
		while (!didMove)//While didMove = false
		{
			int direction = rand() % 4;    //int direction var chooses rand direction between 4 moves

			if ((direction == UP) && (grid[direction] == 'O'))
			{
				delete board[x - 1][y];
				Critter* doodlebug = new Doodlebug(x-1, y, age + 1, 3);
				board[x - 1][y] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;
				didMove = true;
			}	
			else if ((direction == DOWN) && (grid[direction] == 'O'))
			{
				delete board[x + 1][y];
				Critter* doodlebug = new Doodlebug(x+1, y, age + 1, 3);
				board[x + 1][y] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;

				didMove = true;
			}	
			else if ((direction == LEFT) && (grid[direction] == 'O'))
			{
				delete board[x][y - 1];
				Critter* doodlebug = new Doodlebug(x, y - 1, age + 1, 3);
				board[x][y - 1] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;
				didMove = true;
			}
			else if ((direction == RIGHT) && (grid[direction] == 'O'))
			{
				delete board[x][y + 1];
				Critter* doodlebug = new Doodlebug(x, y + 1, age + 1, 3);
				board[x][y + 1] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;
				didMove = true;
			}
		}

	}
	//Check if all spots taken. If they are, your Doodlebug is surrounded by Doodlebugs or the border
	else if (((grid[0] != ' ') || (grid[0] == 'B')) && ((grid[1] != ' ')  || (grid[1] == 'B')) && ((grid[2] != ' ')  || (grid[2] == 'B')) && ((grid[3] != ' ') || (grid[3] == 'B')))
	{
		Critter* doodlebug = new Doodlebug(x, y, age + 1, belly - 1);
		delete board[x][y];
		board[x][y] = doodlebug;
	
		return false;
	}
	//No ant, so move randomly like ant
	else 
	{

		while (!didMove)
		{
			int direction = rand() % 4;    //int direction var chooses rand direction between 4 moves

			if ((direction == UP) && (grid[direction] == ' '))
			{
				delete board[x - 1][y];
				Critter* doodlebug = new Doodlebug(x-1, y, age + 1, belly - 1);
				board[x - 1][y] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;

				didMove = true;
			}
			else if ((direction == DOWN) && (grid[direction] == ' '))
			{
				delete board[x + 1][y];
				Critter* doodlebug = new Doodlebug(x+1, y, age + 1, belly - 1);
				board[x + 1][y] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;

				didMove = true;
			}	
			else if ((direction == LEFT) && (grid[direction] == ' '))
			{
				delete board[x][y - 1];
				Critter* doodlebug = new Doodlebug(x, y - 1, age + 1, belly - 1);
				board[x][y - 1] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;

				didMove = true;
			}
			else if ((direction == RIGHT) && (grid[direction] == ' '))
			{
				delete board[x][y + 1];
				Critter* doodlebug = new Doodlebug(x, y + 1, age + 1, belly - 1);
				board[x][y + 1] = doodlebug;
				delete board[x][y];
				Critter* critter = new Critter;
				board[x][y] = critter;

				didMove = true;
			}
		}
	}
 	return true; 
}

/**********************************************
 * Function returns belly
 *********************************************/ 
int Doodlebug::getBelly()
{
	return belly;
}

