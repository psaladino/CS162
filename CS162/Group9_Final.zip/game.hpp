/*****************************************************************************************************
 * Program:			Group Project
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Game Header file used to introduce the critters to the game board.
 ****************************************************************************************************/

#ifndef GAME_HPP
#define GAME_HPP

#include "Critter.hpp"
#include "Doodlebug.hpp"
#include "Ant.hpp"


int	getRows();		
int	getColumns();			
int	getDoodlebugs(int);
int	getAnts(int, int);
Critter*** createBoard(int, int);			
// Initialize member variables with their x, y locations
void initializeBoard(Critter***, int, int);	
// Prints the board
void printBoard(Critter***, int, int);	
// Fills board with ants
void fillWithAnts(Critter***, int, int, int);		
// Fills board with Doodlebugs
void fillWithDoodlebugs(Critter***, int, int, int);
// free up memory
void destoryBoard(Critter***, int, int);		
//Checks adjacent spaces to an x,y location & returns the objects
char* checkBoard(Critter***, int, int,int,int);     
//Function to place an ant in a space, overwriting the previous
void placeAnt(Critter***, int, int,int);        
//Function to place a doodlebug in a space, overwriting the previous
void placeDoodlebug(Critter***, int, int,int, int);        

#endif
