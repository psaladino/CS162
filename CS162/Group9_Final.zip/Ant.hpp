/**************************************************************************************************
 * Program:			Group Project 
 * Author:			Tyler Anderson, Tyler Durbin, Matthew Musselman, Pierre Saladino, Erik Stone
 * Date:			2/6/2019
 * Description:		Ant class header file.
 **************************************************************************************************/

#ifndef ANT_HPP
#define ANT_HPP
#include "Critter.hpp"

class Ant : public	Critter
{
	private:

	public:
		Ant();
		Ant(int, int, int);
		virtual bool breed(char*);
		virtual bool move(char*, Critter***, int, int);
};
#endif	




 
