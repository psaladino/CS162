/***********************
Author: Pierre Saladino
Description: main method for testing lettersio header and implementation files.
**********************/

#include<iostream>
#include<string>
#include<fstream>
#include "Lettersio.hpp"
using namespace std;

int main()
{

ifstream filein;
ofstream fileout;
string inputname;
string outputname;
int i = 0;
//new counter for each paragraph
int *counter = new int[26];
//promt user for filename
cout << "Please enter the files input name" << endl;
cin >> inputname;

filein.open(inputname);
//file validation
if(!filein)
 {
cout << "Input file cannot be opened" << endl;
exit(0);
 }
//loop to count and write letters to file
while(!filein.eof())
{
count_letters(filein, counter);
}
cout << "Enter output file name" << endl;
cin >> outputname;
i = i + 1;

fileout.open(outputname);

output_letters(fileout, counter);

fileout.close();
filein.close();
// delete allocated memory
delete[] counter;
return 0;
}
