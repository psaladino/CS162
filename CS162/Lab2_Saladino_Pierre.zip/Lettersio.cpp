/*****************
Author: Pierre Saladino
Description: impplementation file for Lettersio. will have two paramter
of ifstream and int for each function. the second function will have ofstream instead.   
****************/

#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>
#include "Lettersio.hpp"
using namespace std;

//function for counting letters and wrtiting to files for each paragraph 
void count_letters(ifstream &filein, int* counter)
{
char ch;
string outputname;
ofstream fileout;
//initializing to 0
for(int i = 0; i < 26; i++)
	counter[i] = 0;  

int count1 = 0;

//loop executes if filein is good 
while(filein.get(ch))
{
//if paragraph breaks asks for output file and writes current letter count 
if(ch == '\n')
 {
	count1++;
	 if(count1 == 2)
	{
	cout << "Enter output file name" << endl;
	cin >> outputname;
	fileout.open(outputname);
	output_letters(fileout, counter); 
	return;
	} 
 }
//checks each letter then updates counter
  if((int)ch >= 97 && (int)ch <= 122)
  {
  counter[(int)ch - 97] += 1;
  }

}
	
}


//output letters function to write results to file
void output_letters(ofstream &fileout, int* counter)
{
int i;
for(i = 0; i < 26; i++)
 {
//for loop used to write each letter with counter to output file
 fileout << (char)(i + 97) << "-" << counter[i] << "\n";
 } 
}













