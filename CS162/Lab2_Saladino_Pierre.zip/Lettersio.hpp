/*****************
Author: Pierre Saladino
Description: Header file for count letters function.
function takes an input file stream variable and a 
Pointer to an array of integers.
The function reads the paragraph string from the input file, then 
counts the letter of frequencies of that pragraph and
stores the frequencies in the array. disregrards uppper/lower case
letters.

2nd header file for output letter functions. takes an output file
stream variable and a pointer to an array of integers that contains
frequencies of letters. the function first asks user for the filename
the user would like to output to then outputs the frequencies of 
letters to the output file
****************/

#ifndef LETTERSIO_HPP
#define LETTERSIO_HPP
#include<fstream>
#include<string>
using namespace std;

//count letter chars function
void count_letters(ifstream &filein , int*);

//writes letters to putput file function
void output_letters(ofstream &fileout, int*);

#endif 
