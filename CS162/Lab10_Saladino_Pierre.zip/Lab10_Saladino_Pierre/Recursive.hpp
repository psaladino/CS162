/*******************************************
**Author: Pierre Saladino
**Description: recursive header file
******************************************/
#ifndef RECURSIVE_HPP
#define RECURSIVE_HPP
#include <stdio.h>
#include <vector>
using namespace std;


int recursiveFibonacci(int n);
void displayFibonacci(int n, vector<long> *recursive);


#endif
