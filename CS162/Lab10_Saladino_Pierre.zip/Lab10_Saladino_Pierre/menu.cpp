/*******************************************
**Author: Pierre Saladino
**Description: menu implementation
******************************************/

#include "Menu.hpp"
#include "Iterative.hpp"
#include "Recursive.hpp"
#include <iostream>
#include <vector>
using namespace std;


//display runtimes of program for recursive and iterative
void viewRuntimes(vector<long> *iterative, vector<long> *recursive, vector<int> *term)
{
    cout << endl << "Runtimes for the Fibonacci Number Calculation: " << endl;
    for (int count = 0; count < iterative->size(); count++)
    {
        cout << "Fibonacci number: " << term->at(count) << "   Iterative: " << iterative->at(count) << " (s)" << "    Recursive: " << recursive->at(count) << " (s)" << endl;
    }
    cout << endl;
    runAgain(iterative, recursive, term);
    
}


//  Function to ask user if they want to run the program again or view .
void runAgain(vector<long> *iterative, vector<long> *recursive, vector<int> *term)
{
    int choice;
    
    cin.clear();
    cout << endl << "***Please select an option below***" << endl;
    cout << "1: Run program again." << endl;
    cout << "2: View runtimes of each program implementation." << endl;
    cout << "3: Exit program." << endl;
    cout << "Enter choice: ";
    cin >> choice;
    while(choice != 1 && choice != 2 && choice != 3)
    {
        cin.clear();
        cin.ignore();
        cout << "Selection invalid. Please try again: " << endl;
        cin >> choice;
    }
    if (choice == 1)
    {
        runProgram(iterative, recursive, term);
    }
    else if (choice == 2)
    {
        viewRuntimes(iterative, recursive, term);
    }
    else
    {
        exit(0);
    }
}

//prompt user fo rnth term, run program for iterative and recursive 
void runProgram(vector<long> *iterative, vector<long> *recursive, vector<int> *term)
{
    int n;
    
    cout << "\nEnter the Fibonacci N(th) term you would like to calculate: ";
    cin >> n;
    while (n <= 0 || n > 500)
    {
        cin.clear();
        cin.ignore();
        cout << "Input invalid. Please enter an integer between 1 and 500: ";
        cin >> n;
    }
    
    term->push_back(n);
    cout << endl;
    
    iterativeFibonacci(n, iterative);
    displayFibonacci(n, recursive);
    runAgain(iterative, recursive, term);
}
