/*******************************************
**Author: Pierre Saladino
**Description: main file
******************************************/
#include "Menu.hpp"
#include "Iterative.hpp"
#include "Recursive.hpp"
#include <iostream>
#include <vector>
using namespace std;


int main() 
{
    vector<long> *iterative = new vector<long>();
    vector<long> *recursive = new vector<long>();
    vector<int> *term = new vector<int>();
    runProgram(iterative, recursive, term);
    
    delete iterative;
    delete recursive;
    delete term;
    
    return 0;
}
