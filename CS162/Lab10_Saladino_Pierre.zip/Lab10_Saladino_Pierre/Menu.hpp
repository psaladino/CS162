/*******************************************
**Author: Pierre Saladino
**Description: menu header file
******************************************/
#ifndef MENU_HPP
#define MENU_HPP
#include <vector>
#include <stdio.h>
using namespace std;

//function prototypes
void viewRuntimes(vector<long> *iterative, vector<long> *recursive, vector<int> *term);
void runAgain(vector<long> *iterative, vector<long> *recursive, vector<int> *term);
void runProgram(vector<long> *iterative, vector<long> *recursive, vector<int> *term);

#endif
