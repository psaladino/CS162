/*******************************************
**Author: Pierre Saladino
**Description: Iterative header file
******************************************/
#ifndef ITERATIVE_HPP
#define ITERATIVE_HPP
#include <stdio.h>
#include <vector>
using namespace std;

void iterativeFibonacci(int n, vector<long> *iterative);

#endif
