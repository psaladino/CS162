/*******************************************
**Author: Pierre Saladino
**Description: recursive implementation file
******************************************/
#include "Recursive.hpp"
#include <iostream>
#include <ctime>
using namespace std;


//takes int n and returns recursive number 
int recursiveFibonacci(int n)
{
    if (n == 0 || n == 1)
    {
        return n;
    }
    else
    {
        return (recursiveFibonacci(n-1) + recursiveFibonacci(n-2));
    }
}


//display time for program in seconds
void displayFibonacci(int n, vector<long> *recursive)
{
    int i = 0;
    int fibonacci;
    clock_t time = clock();
    
    cout << "Calling Recursive Fibonacci implementation...";
    
    while (i < n)
    {
        fibonacci = recursiveFibonacci(i);
        i++;
    }
    time = clock() - time;
    long t = (time / CLOCKS_PER_SEC);
    recursive->push_back(t);
    cout << endl << "The recursive program took " << (time / CLOCKS_PER_SEC) << " seconds to reach the Fibonacci number " << n << endl << endl;
    
}
