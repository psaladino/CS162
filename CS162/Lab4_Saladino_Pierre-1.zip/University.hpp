/*********************************************************************
** Author: Pierre Saladino
** Description: university class file. uses vectors and shared pointers
** 
*********************************************************************/
#ifndef UNIVERSITY_HPP
#define UNIVERSITY_HPP
#include <string>
#include "Person.hpp"
#include "Buildings.hpp"
#include <memory> 
#include <vector>

class University{
private:
std::string name;
std::vector<std::shared_ptr<Person>> people; //uses a shared pointer to people class  
std::vector<std::shared_ptr<Buildings>> buildings; //uses a shared pointer to buildings class

public:
University(std::string name, const std::vector<std::shared_ptr<Person>>& people, const std::vector<std::shared_ptr<Buildings>>& buildings);

void printBuildings();
void printPeople();
void choosePerson();
};
#endif
