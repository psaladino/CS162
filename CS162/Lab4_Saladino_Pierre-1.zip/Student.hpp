/*********************************************************************
** Author: Pierre Saladino
** Description: student class file
*********************************************************************/
#ifndef STUDENT_HPP
#define STUDENT_HPP
#include "Person.hpp" 
#include <string>

//     child          parent
class Student : public Person
{
private:
std::string name;
int hours;
double rating;

public:
Student(std::string name);
virtual void ratingOrGPA();
virtual void do_work(int hours);
};
#endif
