/*********************************************************************
** Author: Pierre Saladino
** Description: building implementation file
*********************************************************************/
#include "Buildings.hpp"
#include <iostream>

//default constructo intializing strings to empty and int to 0
Buildings::Buildings(){
	name = "";
	size = 0;
	address = "";
}
//function passed name, size and address from shared pntr
Buildings::Buildings(std::string name, int size, std::string address){
	this->name = name;
	this->size = size;
	this->address = address;
}
// building print
void Buildings::getName()
{
	std::cout << "Building Name: " << name << std::endl;
}
//area print
void Buildings::getArea()
{
	std::cout << "Area: " << size << " sq ft" << std::endl;
}
//address prints 
void Buildings::getAddress()
{
	std::cout << "Address: " << address << std::endl;
}
