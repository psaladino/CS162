/*********************************************************************
** Author: Pierre Saladino
** Description: building class file
*********************************************************************/
#ifndef BUILDINGS_HPP
#define BUILDINGS_HPP
#include <string>

class Buildings{
private:
//required member variabls
std::string name, address;
int size;

public:
Buildings();//default constructor
Buildings(std::string name, int size, std::string address);//passed name, size and address
void getName();
void getArea();
void getAddress();
};
#endif
