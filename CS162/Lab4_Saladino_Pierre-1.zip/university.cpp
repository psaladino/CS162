/*********************************************************************
** Author: Pierre Saladino
** Description: university implementation file
*********************************************************************/
#include "University.hpp"
#include <iostream>
#include <string>
#include <memory> 
#include <limits>

//consteructor for univeristy class. passed a name of the university
//a vector to Person class and a vector to Building class 
University::University(std::string name, const std::vector<std::shared_ptr<Person>>& people, const std::vector<std::shared_ptr<Buildings>>& buildings)
{
//required member variables
this->name = name;
this->people = people;
this->buildings = buildings;
}

//prints building info
void University::printBuildings()
{
std::cout << "\n********** " << name << " **********\n";
for(int i = 0; i < buildings.size(); i++)
{

buildings[i]->getName();
buildings[i]->getAddress();
buildings[i]->getArea();
std::cout << "----------------------------------------------" << std::endl;
}

}
//prints people info
void University::printPeople()
{

std::cout << "----- People Information -----\n";
for(int i = 0; i < people.size(); i++)
 {
  people[i]->printName();
  std::cout << std::endl;
  people[i]->printAge();
  people[i]->ratingOrGPA();
  std::cout << std::endl;	
 }

}
//prints people info again and asks for user choice. then a random number between 10
//is selected for either HW or grading papers
void University::choosePerson()
{
int choice;
int randomNum = (rand() % (0 - 10));

std::cout << "Choose a person to do work by entering their number from the list\n";

for(int i = 0; i < people.size(); i++)
{
	std::cout << i + 1 << ". ";
	people[i]->printName();
	std::cout << std::endl;
}
	
while(!(std::cin >> choice) || choice < 1 || choice > 2	)
{
std::cin.clear();
std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
std::cout << "Wrong input, please enter a number within range: ";
}
	
std::cout << "----- Work Summary -----\n";
std::cout << std::endl;
people[choice - 1]->do_work(randomNum);
std::cout << std::endl;
}
