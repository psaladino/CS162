/*********************************************************************
** Author: Pierre Saladino
** Description: instructor implementation file
*********************************************************************/
#include "Instructor.hpp"
#include <cstdlib>
#include <iostream>
//instructor constructor with random rating
Instructor::Instructor(std::string name) : Person(name) //base constructor
{
	this->name = name;
}
//prints rating
void Instructor::ratingOrGPA()
{
	double number = (rand() % 50);
	this->rating = number / 10.0;
	std::cout << "Rating: " << rating << std::endl; 
} 
//do work function for instructor
void Instructor::do_work(int hours){
	std::cout << name << " graded papers for " << hours <<" hours.\n";
}
