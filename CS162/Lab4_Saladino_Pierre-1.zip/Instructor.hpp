/*********************************************************************
** Author: Pierre Saladino
** Description: instructor class file
*********************************************************************/
#ifndef INSTRUCTOR_HPP
#define INSTRCUTOR_HPP
#include "Person.hpp"
#include <string>

//	child		   parent
class Instructor : public Person
{
private:
std::string name;
int hours;
double rating;

public:
Instructor(std::string name);
virtual void ratingOrGPA();
virtual void do_work(int hours);
};
#endif
