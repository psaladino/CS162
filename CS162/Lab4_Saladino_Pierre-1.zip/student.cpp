/*********************************************************************
** Author: Pierre Saladino
** Description: student implementation file
*********************************************************************/
#include "Student.hpp"
#include <cstdlib>	
#include <iostream>
#include <random>


Student::Student(std::string name) : Person(name) //base constructor initialization
{
	this->name = name;
}
//prints gpa
void Student::ratingOrGPA()
{
	double number = (rand() % 40);
	this->rating = number / 10.0;
	std::cout << "GPA: " << rating << std::endl;  
}
//do work function for student	
void Student::do_work(int hours)
{
	std::cout << name << " did " << hours << " hours of homework.\n";
}

