/*********************************************************************
** Author: Pierre Saladino
** Description: main file
*********************************************************************/
#include "University.hpp"
#include "Student.hpp"
#include "Instructor.hpp"
#include <iostream>
#include <string>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <limits>


int main()
{
std::string universityName = "Oregon State University";
int choice;
int seed;
seed = time(0);
srand(seed);

//pointers to Person objects
std::vector<std::shared_ptr<Person>> people
{
	std::make_shared<Student> ("Pierre Saladino"),
	std::make_shared<Instructor> ("Luyao Zhang")
};

//create a vector of shared pointers to Buildings objects
std::vector<std::shared_ptr<Buildings>> buildings
{
	std::make_shared<Buildings> ("Adams Hall", 11168, "606 SW 15th st Corvallis, OR 97331"),
	std::make_shared<Buildings> ("Aero Engineering Lab", 3637, "852 SW 30th st, Corvallis, OR 97331")
};

//create university object
University OSU(universityName, people, buildings);

while(true)
{
	std::cout << "\n1) Prints Names of all the buildings\n";
	std::cout << "2) Prints names of everybody at the university\n";
	std::cout << "3) Choose a person to do work\n";
	std::cout << "4) Exit the program\n";

	while(!(std::cin >> choice))
	{
	std::cin.clear();
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cout << "Wrong input, please enter a number: ";
	}
//switch for input cases
	switch(choice)
	{
	case 1:
		OSU.printBuildings();
		break;
	case 2:
		OSU.printPeople();
		break;
	case 3:
		OSU.choosePerson();
		break;
	case 4:
		return 0;
	default:
	std::cout << "invalid choice\n";
	}

	}

return 0;
}
