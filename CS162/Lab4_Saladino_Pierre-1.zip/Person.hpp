/*********************************************************************
** Author: Pierre Saladino
** Description: people class file
*********************************************************************/
#ifndef PERSON_HPP
#define PERSON_HPP
#include <string>

class Person
{
protected:
std::string name;
int hours;
double rating;
int age;

public:
Person();
Person(std::string name);//reseives name
void printName();//prints name
void printAge();//prints age
virtual void ratingOrGPA(); //needed for calling from multiple classes
virtual void do_work(int hours);
};
#endif
