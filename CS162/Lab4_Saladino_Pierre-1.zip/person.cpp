/*********************************************************************
** Author: Pierre Saladino
** Description: person implementation file
*********************************************************************/
#include "Person.hpp"
#include <cstdlib>	
#include <iostream>

//intializing default constructor to empty string and 0
Person::Person()
{
	name = "";
	age = 0;
}
//is passed a people name 
Person::Person(std::string name)
{
	this->name = name;
}
//prints name that is passed
void Person::printName()
{
	std::cout << name;
}
void Person::printAge()
{
	age = (rand() % 60 + 18); //picks random age between 18 and 78
	std::cout << "Age: " << age << std::endl; 
}
//takes hours of person doing work
void Person::do_work(int hours)
{
	this->hours = hours;
}
//intitializing rating to 0
void Person::ratingOrGPA()
{
rating = 0; 
}
