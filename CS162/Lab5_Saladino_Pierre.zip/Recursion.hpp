/*********************************************************************
** Author: Pierre Saladino
** Description: recursive class that encompasses 3 recursive functions.
**1 prints string in reverse, 2. calculates the sum of an array, and 3. calculates triangular number of **int n 
*********************************************************************/


#ifndef RECURSION_HPP
#define RECURSION_HPP
#include <string>

int arraysum(int arr[], int size);//sum array func
std::string reversestring(std::string string);//reverse string func
int triangular(int num);//triangular int func
#endif
