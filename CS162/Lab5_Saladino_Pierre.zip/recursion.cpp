/*********************************************************************
** Author: Pierre Saladino
** Description: recursive class that encompasses 3 recursive functions.
**1 prints string in reverse, 2. calculates the sum of an array, and 3. calculates triangular number of **int n 
*********************************************************************/
#include "Recursion.hpp"
#include <string>
#include <iostream>

//recursive function takes string returns reversed string + first letter 
std::string reversestring(std::string string)
{	
	if(string.length() == 1)
	{
	return string;
	}
	else
	{
	return reversestring(string.substr(1, string.length())) + string.at(0);
	}
}
//takes array and size returns array sum
int arraysum(int arr[], int size)
{
	if(size == 0)
	{
	return 0;
	}	
	return arr[size - 1] + arraysum(arr, size - 1);
}
//takes number returns triangular num
int triangular(int num)
{	
	if(num == 0)
	{
	return 0;
	}
	return num + triangular(num-1);
}


 
