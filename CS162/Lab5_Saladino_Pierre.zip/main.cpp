/*********************************************************************
** Author: Pierre Saladino
** Description: main file for recursion class and implementation files
*********************************************************************/


#include<iostream>
#include<string>
#include "Recursion.hpp"
#include<limits>
#include<sstream>

int main()
{
int choice, arrCount, arrCapacity, num, sum;
std::string string = "";

//menu
while(true)
  {
   std::cout << "\nPlease select a function to call " << std::endl;
   std::cout << "1. First Recursive Function (Reverse String) " << std::endl;
   std::cout << "2. Second Recursive Function (Sum of Array) " << std::endl;
   std::cout << "3. Third Recursive Function (Triangular number) " << std::endl;
   std::cout << "4. Exit Program " << std::endl;

	while (!(std::cin >> choice))
	{
	std::cin.clear();
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
	std::cout << "Please enter an integer " << std::endl;
	}


	switch(choice) 
	{
	case 1: 
		std::cout << "\nEnter a string to be reversed \n" << std::endl;
		std::cin.ignore();
		std::getline(std::cin, string);  
		std::cout << "The reversed string is " << std::endl; 
		std::cout << reversestring(string) << std::endl;//function call to reversestring
		break;
	case 2:
		int* arr;  //pointer to int array per requirements
		arrCapacity = 0; //int for number of elements in array	
		std::cout << "Enter how many numbers you would like to add " << std::endl;
			while (!(std::cin >> arrCapacity ))
			{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
			std::cout << "Please enter an integer " << std::endl;
			} 
	
		arr = new int[arrCapacity];//dynamically creates array for input numbers
	
		for (int i = 0; i < arrCapacity; i++)
		{
		std::cout << "Please enter a number you would like to add " << std::endl;
		while (!(std::cin >> arrCount))
		{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
		std::cout << "Please enter an integer " << std::endl;
		}
		arr[i] = arrCount; //add to new array  
		 
		}  
		  
		sum = arraysum(arr, arrCapacity);
		std::cout << "The sum of the array is " << sum << std::endl;  
		delete [] arr;//delete pointer
		break;
	case 3:
		std::cout << "Please enter an integer " << std::endl;
		while (!(std::cin >> num))
		{
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
		std::cout << "Please enter an integer " << std::endl;
		}
		std::cout << "The triangular number is " << std::endl;
		std::cout << triangular(num) << std::endl;//function call and print
		break;
	case 4:
		exit(0);
	default:
		std::cout << "Invalid choice \n";
	}

   }

return 0;
}














