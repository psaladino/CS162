/*********************************************************************
** Author: Pierre Saladino
** Destcription: game class 
*********************************************************************/
#ifndef GAME_HPP 
#define GAME_HPP
#include "Creature.hpp"
#include "Queue.hpp"

class Game{

	private:
		int firstStrike,
		    p1Points = 0,
		    p2Points = 0;
	public:
		Game();
		int showLosers();
		int fight(Creature* fighter1, Creature* fighter2);
		void determineWinner();
};
#endif