/*********************************************************************
** Author: Pierre Saladino
** Destcription: creature implementation file 
*********************************************************************/

#include "Creature.hpp"
#include <iostream>
#include <cstdlib> //using random

Creature::Creature(std::string name)
{
this -> name = name;
}

//attack function that returns attack, will be inherited by other classes
int Creature::attack()
{
int attackRoll;

attackRoll = roll(attackDie, attackSides);
std::cout << "Attack roll: " << attackRoll << std::endl;

return attackRoll;
}

//defense function inherited by other classes
int Creature::defense(int attack)
{

int defenseRoll, damage;

	//rolls die dependent on character die and sides
	defenseRoll = roll(defenseDie, defenseSides);
	std::cout << "Defense roll: " << defenseRoll << std::endl;

	//takes into account attack defense and armor for damage
	damage = (attack - defenseRoll - armor);

	std::cout << "Attack damage = attack - defenseRoll - armor\n";
	std::cout << damage << " = " << attack << " - " << defenseRoll;
	std::cout << " - " << armor << std::endl;
	

	if(damage > 0)
	{
		std::cout << "Defending fighter's strength before attack: " << strength;
		std::cout << std::endl;
		std::cout << "Strength - damage\n";

		strength -= damage;//damage after the attack

		std::cout << strength << " - " << damage << " = ";
		std::cout << strength;
		std::cout << "\nDefending fighter's strength after attack: " << strength;
		std::cout << std::endl;
	}
	else
	{
		std::cout << "No damage inflicted!\n";
	}
return damage;
}

//rolls die dependent on number of die and sides
int Creature::roll(int numDie, int sidesDie)
{

	int sum = 0;

	for(int rolls = 0; rolls < numDie; rolls++){
		sum += (rand() % sidesDie + 1);
	}

	return sum;
}
//gets strength
int Creature::getStrength()
{

	return strength;
}
//gets armor
int Creature::getArmor()
{

	return armor;
}

void Creature::restore(int damageTotal){
	strength += (damageTotal / 2);
}


/*********************************************************************
** Description: prints out the name of the creature
** Arguments: none
** Returns: none
*********************************************************************/
void Creature::getName(){
	std::cout << name;
	switch(type){
		case 'b': std::cout << " Barbarian\n";
			break;
		case 'B': std::cout << " BlueMen\n";
			break;
		case 'h': std::cout << " Harry Potter\n";
			break;
		case 'm': std::cout << " Medusa\n";
			break;
		case 'v': std::cout << " Vampire\n";
			break;
	}
}