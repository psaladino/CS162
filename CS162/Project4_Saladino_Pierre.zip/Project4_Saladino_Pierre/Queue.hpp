/********************************************
 *Author: Pierre Saladino	
 *Description: queue class
 * ****************************************/
#ifndef QUEUE_HPP
#define QUEUE_HPP
#include "Stack.hpp"
#include "Creature.hpp"
#include "Barbarian.hpp"
#include "Vampire.hpp"
#include "Bluemen.hpp"
#include "Medusa.hpp"
#include "Harrypotter.hpp"
#include <string>

class Queue
{
	//struct for linked list
	struct QueueNode
	{
		Creature* fighter; 
		QueueNode *NEXT;
		QueueNode(Creature* fighter1, QueueNode *next1 = nullptr)
		{
			fighter = fighter1;
			NEXT = next1;
		}

 		//constructor to use when creating the team
		QueueNode(int choice, std::string name, QueueNode *next1 = nullptr)
		{
			//create new creatures based off of fighter choice
			switch(choice){
				case 1:	fighter = new Vampire(name);
							break;
				case 2:	fighter = new Barbarian(name);
							break;
				case 3:	fighter = new Bluemen(name);
							break;
				case 4:	fighter = new Medusa(name);
							break;
				case 5:	fighter = new Harrypotter(name);
							break;
			}
			NEXT = next1;
		}
	};
	QueueNode *baseFront;

	QueueNode *front;
	QueueNode *back;

	public:
	//constructor and desctructor
	Queue();
	~Queue();

	//member functions
	void createTeam(int fighterType, std::string name);
	void addBack();
	Creature* getFront();
	void removeFront();
	void display();
	void getFighterName();
	bool isEmpty();
	int input_integer(std::string prompt);
	int input_integer(int min, int max, std::string prompt);
	int getChoice();
};
#endif
			
