/********************************************
 *Author: Pierre Saladino	
 *Description: game implementation file
 * ****************************************/
#include "Queue.hpp"
#include "Game.hpp"
#include "Barbarian.hpp"
#include "Vampire.hpp"
#include "Bluemen.hpp"
#include "Medusa.hpp"
#include "Harrypotter.hpp"
#include "Stack.hpp"
#include <iostream>
#include <limits> 
#include <cstdlib>
#include <string>

//game constructor
Game::Game()
{
	Stack loserPile;
	int select;
	std::cout << "\nWelcome to Fantasy Combat Tournament \n\n" << std::endl; 
	std::cout << "Please enter a valid menu option\n";
	std::cout << "1) Play Game\n";
	std::cout << "2) Exit\n";

		while(!(std::cin >> select))
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid choice\n";
			std::cout << "Please enter a valid menu option\n";
			std::cout << "1) Play Game\n";
			std::cout << "2) Exit\n";
		}

	if(select == 1)
	{
	std::cout << "\n\n----------------------------------\n\n";
	std::cout << "Create Player 1 Team\n" << std::endl;
	Queue player1;
	player1.display();
	std::cout << "\n\n----------------------------------\n\n";
	std::cout << "Create Player 2 Team\n";
	Queue player2;
	player2.display();

	//fight until one team is queue is empty
	while(!player1.isEmpty() && !player2.isEmpty())
	{
		if(fight(player1.getFront(), player2.getFront()) == 1) 
		{
			p1Points++; 
			std::cout << "\n#### PLAYER 2 DEFEATED ####\n";
			std::cout << "Removing Player 2 Fighter: ";
			player2.getFighterName();		
			loserPile.push(player2.getFront()); 
			player2.removeFront();		 
			std::cout << std::endl;

			//send fighter 1 to the back of the line
			//and remove from front
			std::cout << "Player 1 Winning Fighter: ";
			player1.getFighterName();
			std::cout << " Goes to the back of the line with some health restored!\n";
			player1.addBack();
			player1.removeFront();	
			std::cout << "New line up for Player 1: \n";
			player1.display();
			std::cout << "\n<><><><><><>\n";
		}
		else //fighter 2 wins
		{
			p2Points++; 
			std::cout << "\n#### PLAYER 1 FIGHTER DEFEATED ####\n";
			std::cout << "Removing Player 1 Fighter: ";
			player1.getFighterName();		
			loserPile.push(player1.getFront()); 	
			player1.removeFront();
			std::cout << std::endl;

			//send fighter 2 to the back of the line
			//and remove from front
			std::cout << "Player 2 Winning Fighter: ";
			player2.getFighterName();
			std::cout << " Goes to the back of the line with some health restored!\n";
			player2.addBack();
			player2.removeFront();	
			std::cout << "New line up for Player 2: \n";
			player2.display();
			std::cout << "\n<><><><><><>\n";
		}
	}
	
	//determine winner / display results
	determineWinner();


	//show loser pile
	
	if(showLosers() == 1)
	{
		std::cout << "Displaying the loser pile (stack): \n";
		Creature * losers;
		while(!loserPile.isEmpty())
		{
			std::cout << std::endl;
			loserPile.pop(losers);
			losers->getName();
		}
		std::cout << "\n ^ First Loser on Bottom ^\n";
	exit(0);
	}

	}

	else
	{
	exit(0);
	}

}

//menu to display losers returns choice
int Game::showLosers()
{

	int choice;

		std::cout << "\n----- Display Contents of Loser Pile?-----\n";
		std::cout << "Please enter a valid menu option\n";
		std::cout << "1) Yes\n";
		std::cout << "2) No\n";

		while(!(std::cin >> choice))
		{
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid choice\n";
			std::cout << "\n----- Display Contents of Loser Pile?-----\n";
			std::cout << "Please enter a valid menu option\n";
			std::cout << "1) Yes\n";
			std::cout << "2) No\n";
		}
	
	return choice;
}

//fight function returns a winner
int Game::fight(Creature* fighter1, Creature* fighter2){
	
	bool stillStanding = true;
	int round = 1,
	    damageTotal = 0;
	firstStrike = (rand() % 2 + 1);
	std::cout << "Fighter " << firstStrike << " will attack first\n";

	do{
		switch(firstStrike){
			case 1:
				//fighter 1 attacks
				std::cout << "Fighter 1 attacks!\n";
				damageTotal += fighter2->defense(fighter1->attack());
				std::cout << "Round: " << round++;
				std::cout << " results: ";

				//check if a fighter was defeated
				if(fighter2->getStrength() <= 0){
					std::cout << "Fighter 1 wins!\n";
					fighter1->restore(damageTotal);
					stillStanding = false;
					return 1;
				}
				else{
					std::cout << "The brawl continues...\n";
					std::cout << std::endl;
				}
			case 2:
				//if a fighter has fallen break out of switch
				if(stillStanding == false){
					break;
				}

				//fighter 2 attacks
				std::cout << "Fighter 2 attacks!\n";
				damageTotal += fighter1->defense(fighter2->attack());
				std::cout << "Round: " << round++;
				std::cout << " results: ";

				//check if a fighter was defeated
				if(fighter1->getStrength() <= 0){
					std::cout << "Fighter 2 wins!\n";
					fighter2->restore(damageTotal); 
					stillStanding = false;
					return 2;
				}
				else{
					std::cout << "The brawl continues...\n";
					std::cout << std::endl;
				}
				firstStrike = 1;
		}
		}while(stillStanding); //fight until one fighter is eliminated
}
//checks to see who the winner is
void Game::determineWinner(){
	std::cout << "\n\n------------------------------------\n";
	std::cout << "--------------FINAL RESULTS------------------\n";
	std::cout << "Player 1 Points (wins): " << p1Points;
	std::cout << "\nPlayer 2 Points (wins): " << p2Points;
	std::cout << std::endl;

	if(p1Points > p2Points)
	{
		std::cout << "Player 1 Wins!\n";
	}
	else if (p2Points > p1Points)
	{
		std::cout << "Player 2 Wins!\n";
	}
	else
	{
		std::cout << "Tie\n";
	}
}
