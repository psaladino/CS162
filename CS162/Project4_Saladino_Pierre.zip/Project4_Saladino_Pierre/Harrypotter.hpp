/*********************************************************************
** Author: Pierre Saladino
** Destcription: harrypotter class
*********************************************************************/

#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP
#include "Creature.hpp" //parent class
#include <string>

class Harrypotter : public Creature
{
private:
int revive;
public:
Harrypotter(std::string name);
virtual int defense(int attackDamage) override; 
};
#endif
