/********************************************
 *Author: Pierre Saladino	
 *Description: stack implementation file
 * ****************************************/
#include "Stack.hpp"

//creates new node for loser
void Stack::push(Creature* loser)
{
	top = new StackNode(loser, top);
}

//takes value off top stack
void Stack::pop(Creature* &popLoser)
{
	StackNode *temp;

	if(isEmpty()) 
	{
		throw Stack::Underflow(); 
	}
	else
	{
		//pop value off top of stack
		popLoser = top->loser;
		temp = top;
		top = top->next;
		delete temp;
	}
}
//bool to check if stack is empty
bool Stack::isEmpty() const
{
	return top == nullptr;
}
//destructor
Stack::~Stack()
{
	StackNode * garbage = top;
	while(garbage != nullptr)
	{
		top = top->next;
		garbage->next = nullptr;
		delete garbage;
		garbage = top;
	}
}
