/*********************************************************************
** Author: Pierre Saladino
** Destcription: vampire class using parent class creature
*********************************************************************/

#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP
#include "Creature.hpp" //parent class
#include<string>

class Vampire : public Creature
{
public:
Vampire(std::string name);
virtual int defense(int attack) override; 

};
#endif
