/*********************************************************************
** Author: Pierre Saladino
** Destcription: medusa class
*********************************************************************/

#ifndef MEDUSA_HPP
#define MEDUSA_HPP
#include "Creature.hpp" //parent class
#include<string>

class Medusa : public Creature
{
public:
Medusa(std::string name);
virtual int attack() override; 
};
#endif
