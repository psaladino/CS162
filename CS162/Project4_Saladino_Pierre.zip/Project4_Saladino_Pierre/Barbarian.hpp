/*********************************************************************
** Author: Pierre Saladino
** Destcription: barbarian class 
*********************************************************************/

#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP
#include "Creature.hpp" //parent class
#include<string>

class Barbarian : public Creature
{
public:
Barbarian(std::string name);
};
#endif
