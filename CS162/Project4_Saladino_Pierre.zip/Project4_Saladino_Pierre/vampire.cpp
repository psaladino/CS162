/*********************************************************************
** Author: Pierre Saladino
** Destcription: implementation for vampire class
*********************************************************************/
#include "Creature.hpp"
#include "Vampire.hpp"
#include <iostream>
#include <cstdlib> 

//constructor intitializing variables 
Vampire::Vampire(std::string name) : Creature(name) 
{
armor = 1;
strength = 18;
attackDie = 1;
attackSides = 12;
defenseDie = 1;
defenseSides = 6;
type = 'v';
}

//defense fiunction. using charm there is a 50% chance is not attacked
int Vampire::defense(int attack)
{

int defenseRoll,
    damage,
    charm;


charm = (rand() % 100 + 0);
std::cout << "Charm is at %" << charm << std::endl;
if(charm < 50)
{

	defenseRoll = roll(defenseDie, defenseSides);
	std::cout << "Defense roll: " << defenseRoll << std::endl;

	damage = (attack - defenseRoll - armor);
	std::cout << "Attack damage = attack - defenseRoll - armor\n";
	std::cout << damage << " = " << attack << " - " << defenseRoll;
	std::cout << " - " << armor << std::endl;
		
	if(damage > 0)
	{
	std::cout << "Defending fighter's strength before attack: " << strength;
	std::cout << std::endl;
	std::cout << "Strength - damage\n";

	strength -= damage;

	std::cout << strength << " - " << damage << " = ";
	std::cout << strength;
	std::cout << "\nDefending fighter's strength after attack: " << strength;
	std::cout << std::endl;
	}
	else//if no damage inflicted 
	{
	std::cout << "No damage inflicted!\n";
	}
}
	else
	{
	std::cout << "Charm was succesful! Opponent was charmed!\n";
	}
return damage;

	}
