/*********************************************************************
** Author: Pierre Saladino
** Destcription: bluemen class
*********************************************************************/

#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP
#include "Creature.hpp" //parent class
#include<string>

class Bluemen : public Creature
{
public:
Bluemen(std::string name);
virtual int defense(int attack) override; 
};
#endif
