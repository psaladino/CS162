/********************************************
 *Author: Pierre Saladino	
 *Description: queue implementation
 ******************************************/
#include "Queue.hpp"
#include "Stack.hpp"
#include "Creature.hpp"
#include "Barbarian.hpp"
#include "Vampire.hpp"
#include "Bluemen.hpp"
#include "Medusa.hpp"
#include "Harrypotter.hpp"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

//constructor
Queue::Queue()
{
	baseFront = front = back = nullptr;
	int numFighters,
	    fighterChoice;
	std::string name;
	
	std::cout << "Tournament play requires atleast 2 fighters per team!\n";
	numFighters = input_integer(2, 50, "Enter the number of fighters: ");

	for(int count = 0; count < numFighters; count++)
	{
		fighterChoice = getChoice();

		std::cout << std::endl;
		std::cout << "Enter the name of fighter ";
		std::cout << count + 1 << ": ";
		
		std::cin.ignore();
		getline(std::cin, name);
	
		createTeam(fighterChoice, name);
	}
}

//creates team 
void Queue::createTeam(int fighterType, std::string name)
{
	if(isEmpty()) //queue is empty, create the first node
	{
		std::cout << "\nCREATING FIRST FIGHTER\n";
		baseFront = new QueueNode(fighterType, name);
		back = front = baseFront;
	}
	else	//queue is full, create a new back node
	{
		//create a new back node        	  
		back->NEXT = new QueueNode(fighterType, name);
		//set back to the newly created node above
		back = back->NEXT;
	}
}

//adds to back node
void Queue::addBack()
{
		back->NEXT = new QueueNode(front->fighter);
		back = back->NEXT;
}

//gets front node
Creature* Queue::getFront()
{
	if(isEmpty())
	{
		//Queue Empty
		std::cout << "Fight Queue Empty\n";
	}
	else
	{
		return front->fighter;
	}
}

//removes front node as fight ends
void Queue::removeFront()
{
	if(isEmpty())
	{
		std::cout << "Queue Empty, fight is over\n";
	}
	else
	{
		//temp = front;
		front = front->NEXT;
		
	}
}

//display fighter queue, returns nothing
void Queue::display()
{
	//check if the queue is empty
	if(!isEmpty())
	{
		std::cout << "~~~~~~~~~~~~~~\n";
		std::cout << "Fighter Queue:   \n\n";
		//temp used to traverse queue
		QueueNode *traverse = front;
		
		//print the first node
		traverse->fighter->getName();

		//traverse until the back node is reached
		while(traverse != back)
		{
			std::cout << std::endl;
			traverse = traverse->NEXT;
			traverse->fighter->getName();
		}
		std::cout << std::endl;
	}
	else
	{
		//Queue is empty
		std::cout << "Error: Queue Empty\n";
	}
}

//gets name for each fighter
void Queue::getFighterName()
{
	front->fighter->getName();
}

//bool to check queue
bool Queue::isEmpty()
{
	if(front == nullptr)
	{
		return true;
	}
	else
	{
		return false;
	}
}
//returns input from user 
int Queue::input_integer(std::string prompt)
{
	std::string user_input;
	bool input_is_valid = false;
	int return_integer;

	do
	{
		std::cout << prompt;
		getline(std::cin, user_input);

		try //convert the user input into an integer
		{
			//check for digits
			if(!(user_input.find_first_not_of("-0123456789")))
			{
				throw std::runtime_error("non-numeric character inputed");
			}
			return_integer = stoi(user_input);
			input_is_valid = true;

		} catch(const std::exception& e)
		{
			//number could not be converted.
			std::cout << "Error: \"" << user_input << "\" is invalid." << std::endl;
			input_is_valid = false;
		}

	} while(!input_is_valid);

	return return_integer;
}

//returns input from user
int Queue::input_integer(int min, int max, std::string prompt)
{
	if(min > max)
	{
	throw std::invalid_argument("min is greater than max");
	}

	int user_input;
	bool input_is_valid;
	do
	{
		user_input = input_integer(prompt);
		if((user_input > max) || (user_input < min))
		{
			input_is_valid = false;
std::cout << "Error: enter an integer that's between " << min << " and " << max << "." << std::endl;
		} else {
			input_is_valid = true;
		}
	} while(!input_is_valid);

	return user_input;
}

//choice for fighters, returns int
int Queue::getChoice(){

	int fighterChoice;

	do{
		//fighter menu options
		std::cout << "----- Choose Your Fighters! -----\n";
		std::cout << "Please enter a valid menu option\n";
		std::cout << "1) Vampire\n";
		std::cout << "2) Barbarian\n";
		std::cout << "3) Blue Men\n";
		std::cout << "4) Medusa\n";
		std::cout << "5) Harry Potter\n";

		//menu selection error handling
		while(!(std::cin >> fighterChoice)){
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid choice\n";
			//display menu options again
			std::cout << "----- Choose Your Fighters! -----\n";
			std::cout << "Please enter a valid menu option\n";
			std::cout << "1) Vampire\n";
			std::cout << "2) Barbarian\n";
			std::cout << "4) Medusa\n";
			std::cout << "5) Harry Potter\n";
		}
	}while(fighterChoice < 1 || fighterChoice > 5);
	return fighterChoice;
}

//desructor deletes new memory
Queue::~Queue()
{
	std::cout << "destructor starting..\n";
	//set the front node to original base front 	
	front = baseFront; 
	QueueNode * garbage = front;

	
	while(garbage->NEXT != nullptr);
	{
		front = front->NEXT;
		garbage->NEXT = nullptr;
		delete garbage->fighter; //delete fighter (created with new) in node
		garbage->fighter = nullptr;
		delete garbage;
		garbage = front;
	}
	delete back->fighter;
	back->fighter = nullptr;
	delete back;

}
