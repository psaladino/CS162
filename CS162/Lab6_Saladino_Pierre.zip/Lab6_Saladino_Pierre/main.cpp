/****************************************
**Author: Pierre Saladino
**Description: Main exectutable file. includes
**main menu 
****************************************/
#include "Node.hpp"
#include <unistd.h>
#include <iostream>
using namespace std;


//displays menu
void displayMenu()
{
    int choice = 0;
    int number;
    DoublyLinkedList nodeList;//creates nodelist objects of doublylinkedlist class 
    
    cout << endl << "*************Doubly-Linked List Program************" << endl << endl;
    

    while(choice != 6)
    {
        cout << "Please select an option below:" << endl;
        cout << "1: Add a new node to the head." << endl;
        cout << "2: Add a new node to the tail." << endl;
        cout << "3: Delete the first node in the list." << endl;
        cout << "4: Delete the last node in the list." << endl;
        cout << "5: Traverse the list reversely." << endl;
        cout << "6: Exit the program." << endl;
        
        cin >> choice;
            
    	//if input is not valid display menu 
        while (choice < 1 || choice > 6)
        {
            cout << "Invalid input. Please try again." << endl;
            cin.clear();
            cin.ignore();
            displayMenu();
        }

        switch (choice)
        {
            case 1:
                cout << "Please enter the value you would like to add: ";
                cin >> number;
                cin.clear();
                cin.ignore();
                while (number < 1)
                {
                    cout << "Enter an integer greater than 0. Please try again: ";
                    cin >> number;
                    cin.clear();
                    cin.ignore();
                }
                cout << endl;
                nodeList.addHeadNode(number);//calls function to add int to node
                nodeList.traverseList();//displays current node list
                break;
            case 2:
                cout << "Please enter the value you would like to add: ";
                cin >> number;
                cin.clear();
                cin.ignore();
                while (number < 1)
                {
                    cout << "Enter an integer greater than 0. Please try again: ";
                    cin >> number;
                    cin.clear();
                    cin.ignore();
                }
                cout << endl;
                nodeList.addTailNode(number);//calls function to add int to tail end of node
                nodeList.traverseList();//displays current node list
                break;
            case 3:
                nodeList.deleteFirstNode();//calls function to delete head node
                nodeList.traverseList();
                break;
            case 4:
                nodeList.deleteLastNode();//calls function to delete tail node
                nodeList.traverseList();
                break;
            case 5:
                nodeList.traverseReversely();//displays listn reverse 
                nodeList.traverseList();
                break;
            case 6:
		nodeList.deletePointers();//deletes allocated memory upon exit
		exit(0);
		
        }
    }
}

int main()
{
displayMenu();//starts program 
return 0;
}
