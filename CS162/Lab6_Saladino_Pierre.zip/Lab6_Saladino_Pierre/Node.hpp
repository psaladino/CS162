/****************************************
**Author: Pierre Saladino
**Description: class of doubly linked list  
** 
****************************************/

#ifndef NODE_HPP
#define NODE_HPP

//node structure of pointers and val per reqs
struct Node
{
    Node *next;
    Node *prev;
    int val;
};


class DoublyLinkedList
{
private:
Node *head;
Node *tail;

public:
DoublyLinkedList();//constructor
void addHeadNode(int value);//add to head node
void addTailNode(int value);//add to tail node
void deleteFirstNode();//delete head
int deleteLastNode();//delete tail
void traverseReversely();//reverse order
void traverseList();//print correct order
void deletePointers();//deletes pointers
};
#endif
