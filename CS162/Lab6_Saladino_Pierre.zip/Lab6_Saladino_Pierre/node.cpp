/****************************************
**Author: Pierre Saladino
**Description: implementation file for doubly linked list 
** class
****************************************/

#include <unistd.h>
#include <iostream>
#include "Node.hpp"
using namespace std;  

 // Constructor intialiding head and tail nodes
DoublyLinkedList::DoublyLinkedList()
  {
      head = nullptr;
      tail = nullptr;
  }
//adds int to head of nodeslist
void DoublyLinkedList::addHeadNode(int value)
   {
       Node *ptr = new Node();
       ptr -> val = value;
       if (tail == nullptr)
       {
           head = tail = ptr;
       }
       else
       {
           ptr -> next = head;
           head -> prev = ptr;
           head = ptr;
       }
   }
    
// adds int to tail end of node list
void DoublyLinkedList::addTailNode(int value)
   {
       Node *ptr = new Node();
       
       ptr -> val = value;
       if (head == nullptr)
       {
           head = tail = ptr;
       }
       else
       {
           ptr -> prev = tail;
           tail -> next = ptr;
           tail = ptr;
       }
       
   }
    
// deletes first int of node list (head)
void DoublyLinkedList::deleteFirstNode()
   {
       if (head != nullptr)
       {
	Node *ptr = head -> next;
       	delete head;
	head = ptr;
       }
   }
    
// delete last node of node list
int DoublyLinkedList::deleteLastNode()
    {
        Node *ptr = tail;
        if (tail -> prev != nullptr)
        {
            tail -> prev -> next = nullptr;
        }
        tail = tail -> prev;
        int val = ptr -> val;
        delete ptr;
        return val;
    }
    
// reverse node list 
void DoublyLinkedList::traverseReversely()
   {
       Node *ptr = tail;
       cout << "The current node list in reverse is: ";
       if (ptr == nullptr)
       {
           cout << "The node list is empty." << endl;
           return;
       }
       while (ptr != nullptr)
       {
           cout << ptr -> val << " ";
           ptr = ptr -> prev;
       }
       cout << endl << endl;
   }
    
// the list in correct order
void DoublyLinkedList::traverseList()
   {
       Node *ptr = head;
       cout << "The current node list is: ";
       if (ptr == nullptr)
       {
           cout << "The node list is empty. " << endl;
           return;
       }
       while (ptr != nullptr)
       {
           cout << ptr -> val << " ";
           ptr = ptr -> next;
       }
       cout << endl << endl;
   }

//deletes allocated new memory
void DoublyLinkedList::deletePointers()
{
Node *ptr = head;
	while( ptr != nullptr)
	{
	Node *garbage = ptr;
	ptr = ptr -> next;
	delete garbage;
	}
}










