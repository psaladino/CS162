/*********************************************************************
** Author: Pierre Saladino
** Description: header file for choice function 
*********************************************************************/
#ifndef GETCHOICE_HPP
#define GETCHOICE_HPP

int getChoice();

#endif
