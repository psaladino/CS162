/*********************************************************************
** Author: Pierre Saladino 
** Description: main file for project 1 ant starts at a determined location
*from the user then begins by moving forward. aftet the program is 
*finished. user will be prompted by menu  
*********************************************************************/
#include <iostream>
#include<string>
#include <unistd.h> 
#include "ant.hpp"

//menu function prototypes
void displayMenu();
int getChoice();

int main()
{
	int numRows, numCols, numSteps, startRow, startCol, choice = 1;

	while(choice == 1) //choice is set to 1 to begin the simulation
	{//get boundaries for board
	std::cout << "\n Langton's Ant  Simulator\n\n";
	do  
	{
	std::cout << "\nEnter the number of rows\n";
	std::cin >> numRows;
	}
	while(numRows <= 0);

	do 
	{
	std::cout << "\nEnter the number of columns\n";
	std::cin >> numCols;
	}
	while(numCols <= 0);

	do 
	{//get steps
	std::cout << "\nEnter the number of steps\n";
	std::cin >> numSteps;
	}
	while(numSteps <= 0);

	do
	{
	std::cout << "\nEnter the starting row\n";
	std::cin >> startRow;
	}
	while(startRow <= 0 || startRow > numRows); 
      
	do
	{
	std::cout << "\nEnter the starting col\n";
	std::cin >> startCol;
	}
	while(startCol <= 0 || startCol > numCols);

	Ant newAnt(numRows, numCols);

	newAnt.printGrid();
	std::cout << "# is black, ' ' is white, and * is the ant\n";
	std::cout << std::endl;
	sleep(1);//pauses for 1 sec before printing new board
	//place ant on board to start
	newAnt.placeAnt(startRow, startCol, numSteps);

	displayMenu();
	choice = getChoice();
	}

	std::cout << "\n\nprogram over\n";

	return 0;
}
