/*********************************************************************
** Author: Pierre Saladino 
** Description: header file for ant class. contains ant location
** and orientation
*********************************************************************/
#ifndef ANT_HPP
#define ANT_HPP
enum direction {UP, DOWN, LEFT, RIGHT};//direction data type to change directions

class Ant
{
private:
char** grid;
char color;
direction currentDirection;
int rows, columns, movX, movY, moves;

public:
Ant(int, int);//size of board
void placeAnt(int, int, int);//ants starting point on the board and number of steps
void flipDirection(direction);//change the ants direction
void printGrid();//print board
char checkColor(int x, int y);//checks for black or white space
~Ant(); //destructor for grids
};
#endif
