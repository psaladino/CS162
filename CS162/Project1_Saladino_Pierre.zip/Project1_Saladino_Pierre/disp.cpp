/*********************************************************************
** Author: Pierre Saladino
** Description: implementation file for display menu
*********************************************************************/

#include <iostream>

void displayMenu()
{
	std::cout << "Press 1 to run again\n";
	std::cout << "Press 2 to quit\n";
}
