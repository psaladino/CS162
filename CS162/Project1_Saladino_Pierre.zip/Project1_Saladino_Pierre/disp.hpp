/*********************************************************************
** Author:Pierre Saladino 
** Description: display header file
*********************************************************************/
#ifndef DISPLAYMENU_HPP
#define DISPLAYMENU_HPP

void displayMenu();

#endif
