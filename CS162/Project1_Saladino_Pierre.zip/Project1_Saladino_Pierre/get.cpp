/*********************************************************************
** Author: Pierre Saladino
** Description: implementation file for getchoice
*********************************************************************/

#include <iostream>

int getChoice()
{
int choice;
std::cin >> choice;
while(choice < 1 || choice > 2)
{
std::cout << "Enter 1 or 2";
std::cin >> choice;
}
return choice;
}
