/********************************************
*Author: Pierre Saladino
*Description: game class used to implement 
*the dice war rolling game.includes a menu to
*ask the user to play game or extit. 
*
*******************************************/

#ifndef GAME_HPP
#define GAME_HPP
#include "Die.hpp"
#include "loadedDie.hpp" 

class Game
{
private:
// pointers to die 
Die* p1pointer;
Die* p1pointer2;
Die* p2pointer;
Die* p2pointer2;

int choice, p1die, p2die, p1side1, p1side2, p2side1, p2side2, p1win, p2win;

int p1total, p2total, rounds, draw;

public:

Game();//constructor
void getrounds();//input for rounds
void getdie();//inputs for die
void getsides();//inputs for # of sides
void dieroll();//play game 
void setdie();// sets die
~Game();//destructor

};
#endif
