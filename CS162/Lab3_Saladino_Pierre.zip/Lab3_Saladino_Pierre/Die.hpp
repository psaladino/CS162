/********************************************
 *Author: Pierre Saladino
 *Description: Die class. uses member variable
 *n that represents number of sides on individual 
 *die. member function for returning random
 *integer between 1 and N.
 * ****************************************/

#ifndef DIE_HPP
#define DIE_HPP

class Die
{
protected: 
	int N;//int for sides
public:
Die();	//constructor intitializing N 
Die(int N);//sets number of sides after taking number of sides as input
virtual int roll(); // roll for Die class, has virtual tag for child class 
};
#endif
