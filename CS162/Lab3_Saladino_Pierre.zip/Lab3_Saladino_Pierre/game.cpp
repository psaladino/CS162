/********************************************
*Author: Pierre Saladino
*Description: game implementation file.  
*will prompt user with a menu, ask for rounds, 
* die sides, and display results 
*
*******************************************/

#include<iostream>
#include<limits>
#include "Game.hpp" 
using namespace std;

//display menu  with input validation, asks for user input. 
Game::Game()
{
int choice = 0;
cout << "\n War Game (with dice)\n" << endl;  
cout << "Enter 1 to play\n" << endl;
cout << "Enter 2 to quit\n" << endl;
//input validation used for all inputs byt limiting choices
while (!(cin >> choice) || choice < 1 || choice > 2)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter 1 or 2" << endl; 
}
this ->choice = choice;


if (choice == 2)
{
exit (0);
} 

if (choice == 1)
{
cout << "\n**********Welcome to War Dice Game**********\n" << endl; 
}
//initializing wins
p1win = p2win = 0;

getrounds();

getdie();

getsides();

setdie();

//begins for loop to roll dice until game is over 
for(int r = 0; r < rounds; r++) 
{
dieroll();
}
//displays final results of winner
cout << "\n**********Final results********** \n" << endl;

if (p1die == 1)
{
cout << "\nPlayer 1 was using NORMAL die with sides " << p1side1 << " and "<< p1side2 << endl;
cout << "Player 1 had a total of " << p1win << " wins" << endl;   
}

else if (p1die == 2)
{
cout << "\nPlayer 1 was using LOADED die with sides " << p1side1 << " and "<< p1side2 << endl;
cout << "Player 1 had a total of " << p1win << " wins" << endl;   
}



if (p2die == 1)
{
cout << "\nPlayer 2 was using NORMAL die with sides " << p2side1 << " and "<< p2side2 << endl;
cout << "Player 2 had a total of " << p2win << " wins" << endl;   
}

else if (p2die == 2)
{
cout << "\nPlayer 2 was using LOADED die with sides " << p2side1 << " and "<< p2side2 << endl;
cout << "Player 1 had a total of " << p2win << " wins" << endl;   
}

if(p1win > p2win)
{
cout << "\n**********P1 wins!**********\n" << endl; 
cout << "\n There were " << draw << " draws" << endl; 
} 
else if(p2win > p1win)
{
cout << "\n**********P2 wins!**********\n" << endl; 
cout << "\n There were " << draw << " draws" << endl; 
} 
else 
{
cout << "\n********** Game is a DRAW!**********\n" << endl;
}

}
//recieves user input for rounds
void Game::getrounds()
{
int rounds;
cout << "Please enter how many rounds will be played\n" << endl;
while (!(cin >> rounds) || rounds <= 0 || rounds > 100)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter an integer between 1-100" << endl; 
}
this ->rounds = rounds;
}
//receives die input
void Game::getdie()
{
cout << "\nEnter the die type for Player 1\n" << endl;

cout << "\nEnter 1 for normal or 2 for loaded die\n" << endl;
while (!(cin >> p1die) || p1die < 1 || p1die > 2)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter 1 or 2" << endl; 
}

cout << "\nEnter the die type for Player 2\n" << endl;
while (!(cin >> p2die) || p2die < 1 || p2die > 2)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter 1 or 2" << endl; 
}
 
}
//recieves die for each player, (can be 2 different sides) 
void Game::getsides()
{
cout << "\nHow many sides does Player 1's die 1 have\n" << endl;
while (!(cin >> p1side1) || p1side1 < 1 || p1side1 > 100)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter an integer between 0-100" << endl; 
}
cout << "\nHow many sides does his die 2 have\n" << endl;
while (!(cin >> p1side2) || p1side2 < 1 || p1side2 > 100)
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter an integer between 0-100" << endl; 
}

cout << "\nHow many sides does Player 2's die 1 have\n" << endl; 
while (!(cin >> p2side1) || p2side1 < 1 || p2side1 > 100) 
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter an integer between 0-100" << endl; 
}
cout << "\nHow many sides does his die 2 have\n" << endl;
while (!(cin >> p2side2) || p2side2 < 1 || p2side2 > 100) 
{
cin.clear();
cin.ignore(numeric_limits<streamsize>::max(), '\n');
cout << "Please enter an integer between 0-100" << endl; 
}

} 
//sets pointers to die for roll 
void Game::setdie()
{
switch(p1die)
{
case 1: p1pointer = new Die(p1side1), p1pointer2 = new Die(p1side2);
break;
case 2: p1pointer = new loadedDie(p1side1), p1pointer2 = new loadedDie(p1side2);
}
 
switch(p2die)
{
case 1: p2pointer = new Die(p2side1), p2pointer2 = new loadedDie(p2side2);
break;
case 2: p2pointer = new loadedDie(p2side1), p2pointer2 = new loadedDie(p2side2);
}

}
//roll die function that rolls die
void Game::dieroll()
{
int p1roll, p2roll;
int p1roll2, p2roll2;

p1roll = p1pointer-> roll();
cout << "Player 1 DIE1 rolled a " << p1roll << endl;
p1roll2 = p1pointer2-> roll();
cout << "Player 1 DIE2 rolled a " << p1roll2 << endl;

p2roll = p2pointer -> roll();
cout << "Player 2 DIE1 rolled a " << p2roll << endl;
p2roll2 = p2pointer2 -> roll();
cout << "Player 2 DIE2 rolled a " << p2roll2 << endl;

if (p1roll > p2roll)
{
cout << "Player 1 wins the round!" << endl;
p1win++;
} 

else if (p2roll > p1roll)
{
cout << "Player 2 wins the round!" << endl;
p2win++;
}

else
{
cout << "Its a DRAW!" << endl;
draw++;
}

if (p1die == 1)
{
cout << "Player 1 is using" << " NORMAL DIE" << endl; 
cout << "With sides " << p1side1 << " & " << p1side2  << endl;   
}

if (p1die == 2)
{
cout << "Player 1 is using" << " LOADED DIE" << endl; 
cout << "With sides " << p1side1 << " & " << p1side2  << endl;   
}

if (p2die == 1)
{
cout << "Player 2 is using" << " NORMAL DIE" << endl; 
cout << "With sides " << p2side1 << " & " << p2side2  << endl;   
}

if (p2die == 2)
{
cout << "Player 2 is using" << " LOADED DIE" << endl; 
cout << "With sides " << p2side1 << " & " << p2side2  << endl;   
}



cout << "Player 1 has " << p1win << " wins" << endl; 
cout << "Player 2 has " << p2win << " wins" << endl;  
cout << "****************************************************************" << endl;
cout << "****************************************************************" << endl;
}

//delete allocated memory
Game::~Game()
{
delete p1pointer;
delete p1pointer2;
delete p2pointer;
delete p2pointer2;
p1pointer = NULL;
p1pointer2 = NULL;
p2pointer = NULL;
p2pointer2 = NULL;
}










