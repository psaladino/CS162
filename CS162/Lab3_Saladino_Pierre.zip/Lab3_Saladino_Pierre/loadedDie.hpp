/********************************************
**Author: Pierre Saladino
**Description: Loaded die class which has the  
** same elements of die class. returns a biased
** number when rolling where the average output
** is several times higher than that of die. 
* ******************************************/

#ifndef LOADEDDIE_HPP
#define LOADEDDIE_HPP
#include "Die.hpp"
//inhertits from Die class 
class loadedDie : public Die
{
public:

int N;

public:

loadedDie();

loadedDie(int N);

virtual int roll();

};
#endif
