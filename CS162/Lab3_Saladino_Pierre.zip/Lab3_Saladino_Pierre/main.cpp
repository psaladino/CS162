
/********************************************
*Author: Pierre Saladino
*Description:mplementation file for die hpp 
* 
*
*******************************************/
#include<iostream>
#include<string>
#include<cstdlib>
#include<ctime>
#include "Game.hpp"
using namespace std;

int main()
{

int seed;
seed = time(0);
srand(seed);
Game newGame;

return 0;
}  
