/********************************************
*Author: Pierre Saladino
*Description:mplementation file for die hpp 
* 
*
*******************************************/

#include<cstdlib>
#include "Die.hpp"
//default constructor initializing a side (N)
Die::Die()
{
N = 4;
}
//uses pointer to this side 
Die::Die(int N)
{
this->N = N;
}
//roll dies for Die
int Die::roll()
{
// picks random number from N sides 
int results = rand() % N + 1;
return results;
}
