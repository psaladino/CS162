/********************************************
**Author: Pierre Saladino
**Description: Loaded die implementation class.
**inherits Die class elements
**
** 
*******************************************/

#include "loadedDie.hpp"
#include <cstdlib>
//constructor
loadedDie::loadedDie() : Die()
{
this->N = 4;
}
//passed N and sets sides
loadedDie::loadedDie(int N) : Die(N) 
{
this-> N = N;
}

//roll from parent class
int loadedDie::roll()
{
//averages hinger than regular die roll
int results = (rand() % (N - (N / 2)))
			 + (N / 2);
return results;
}








