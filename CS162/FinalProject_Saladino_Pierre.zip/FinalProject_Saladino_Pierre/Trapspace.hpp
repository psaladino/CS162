/***********************************
**Author: Pierre Saladino
**Description: trapspace class file
**********************************/

#ifndef TRAPSPACE_HPP
#define TRAPSPACE_HPP
#include "Space.hpp"
#include <stdio.h>


class TrapSpace : public Space
{
private:
    
public:
    TrapSpace();
    bool getItem();
    bool getExit();
    bool getTrap();
};


#endif
