/***********************************
**Author: Pierre Saladino
**Description: exit space implementation
**********************************/


#include "Exitspace.hpp"
#include <iostream>
using namespace std;


//constructor
ExitSpace::ExitSpace()
{
    trap = false;
    item = false;
    exit = true;
}


// bool, returns item 
bool ExitSpace::getItem()
{
    return item;
}


//bool returns exit 
bool ExitSpace::getExit()
{
    return exit;
}


//bool returns trap variable
bool ExitSpace::getTrap()
{
    return trap;
}
