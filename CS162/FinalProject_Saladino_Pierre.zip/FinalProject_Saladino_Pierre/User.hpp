/***********************************
**Author: Pierre Saladino
**Description: user class file
**********************************/

#ifndef USER_HPP
#define USER_HPP

#include <stdio.h>

class User
{
private:
    double health;
    int steps;
    bool win;
    bool lose;
public:
    User();
    double getHealth();
    void setSteps();
    int getSteps();
    void reduceHealth();
    void addHealth();
    void setWinGame();
    bool getWinGame();
    void setLoseGame();
    bool getLoseGame();
};

#endif
