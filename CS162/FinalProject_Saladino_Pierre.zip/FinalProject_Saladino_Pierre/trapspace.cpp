/***********************************
**Author: Pierre Saladino
**Description: trap space implementation file
**********************************/

#include "Trapspace.hpp"

//constructor
TrapSpace::TrapSpace()
{
    trap = true;
    item = true;
    exit = false;
}


//check if space has an item
bool TrapSpace::getItem()
{
    return item;
}


//check if space has an exit
bool TrapSpace::getExit()
{
    return exit;
}


//check if space has a trap
bool TrapSpace::getTrap()
{
    return trap;
}
