/***********************************
**Author: Pierre Saladino
**Description: space implementation file
**********************************/

#include "Space.hpp"


//current space
void Space::setSpace(int userLoc)
{
    space = userLoc;
    number = space;
}


//return current location
int Space::getSpace()
{
    return number;
}


//set top space
void Space::setTop(int topLoc)
{
    top = topLoc;
}


//returns top space
int Space::getTop()
{
    return top;
}


//set bottom space
void Space::setBottom(int bottomLoc)
{
    bottom = bottomLoc;
}


//return bottom space
int Space::getBottom()
{
    return bottom;
}


//set right space
void Space::setRight(int rightLoc)
{
    right = rightLoc;
}


//return right space
int Space::getRight()
{
    return right;
}


//set left space
void Space::setLeft(int leftLoc)
{
    left = leftLoc;
}


//return left space
int Space::getLeft()
{
    return left;
}


//virtual function per req
bool Space::getItem()
{
    return item;
}


//virtual function checks space for exit
bool Space::getExit()
{
    return exit;
}


//virtual function checks if trap
bool Space::getTrap()
{
    return trap;
}
