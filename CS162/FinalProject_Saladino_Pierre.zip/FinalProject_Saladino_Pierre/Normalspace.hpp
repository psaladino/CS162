/***********************************
**Author: Pierre Saladino
**Description: normal space class file
**********************************/

#ifndef NORMALSPACE_HPP
#define NORMALSPACE_HPP
#include "Space.hpp"
#include "Menu.hpp"
#include <stdio.h>

class NormalSpace : public Space
{
private:
    
public:
    NormalSpace();
    bool getItem();
    bool getExit();
    bool getTrap();
};

#endif
