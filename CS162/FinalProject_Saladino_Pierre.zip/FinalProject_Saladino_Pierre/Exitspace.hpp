/***********************************
**Author: Pierre Saladino
**Description: exit space header file
**********************************/

#ifndef EXITSPACE_HPP
#define EXITSPACE_HPP
#include "Space.hpp"
#include <stdio.h>

class ExitSpace : public Space
{
private:
    
public:
    ExitSpace();
    bool getItem();
    bool getExit();
    bool getTrap();
    
};


#endif
