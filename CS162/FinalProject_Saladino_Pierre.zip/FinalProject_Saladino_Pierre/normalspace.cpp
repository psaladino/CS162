/***********************************
**Author: Pierre Saladino
**Description: normal space implementation file
**********************************/

#include "Normalspace.hpp"


//nitializing constructor
NormalSpace::NormalSpace()
{
    int itemChance = 1 + rand() % ((2+1) - 1);
    if (itemChance == 1)
        item = true;
    else
        item = false;
    trap = false;
    
    exit = false;
}


//returns item 
bool NormalSpace::getItem()
{
    return item;
}


//returns exit
bool NormalSpace::getExit()
{
    return exit;
}


//returns trap
bool NormalSpace::getTrap()
{
    return trap;
}
