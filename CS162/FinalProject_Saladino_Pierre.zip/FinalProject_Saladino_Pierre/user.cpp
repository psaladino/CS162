/***********************************
**Author: Pierre Saladino
**Description: user implementation file
**********************************/

#include "User.hpp"


//constructor
User::User()
{
    health = 100;
    steps = 15;
    win = false;
    lose = false;
}


//return current health
double User::getHealth()
{
    return health;
}


//reduce step--
void User::setSteps()
{
    this -> steps = steps - 1;
}


//return step
int User::getSteps()
{
    return steps;
}


//reduce health by 20
void User::reduceHealth()
{
    health = health - 20;
}


//add 15 health
void User::addHealth()
{
    health = health + 15;
}


//set win to true
void User::setWinGame()
{
    win = true;
}


//return win 
bool User::getWinGame()
{
    return win;
}


//set lose to true
void User::setLoseGame()
{
    lose = true;
}


//return lose 
bool User::getLoseGame()
{
    return lose;
}
