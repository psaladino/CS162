/***********************************
**Author: Pierre Saladino
**Description: inventory implementation file
**********************************/

#include "Inventory.hpp"
#include <vector>
#include <iostream>
#include <string>
#include <list>
using namespace std;


//constructor initilalizing to 0
Inventory::Inventory()
{
    size = 0;
    healthPotion = false;
    key = false;
    trapPotion = false;
    keyPos = 0;
    healthPotPos = 0;
    trapPotPos = 0;
    keyQuant = 0;
    healthPotQuant = 0;
    trapPotQuant = 0;
}


//size++
void Inventory::incSize()
{
    size = size + 1;
}


//size--
void Inventory::decSize()
{
    size = size - 1;
}


//return size
int Inventory::getSize()
{
    return size;
}


//item++
void Inventory::addItem(int item)
{
    backpack.push_back(item);
    if (item == 1)
    {
        keyQuant = keyQuant + 1;
        key = true;
    }
    else if (item == 2)
    {
        healthPotQuant = healthPotQuant + 1;
        healthPotion = true;
    }
    else
    {
        trapPotQuant = trapPotQuant + 1;
        trapPotion = true;
    }
}


//item--
void Inventory::decItem(int item)
{
    if (backpack.at(item) == 1)
    {
        keyQuant = keyQuant - 1;
        if (keyQuant < 1)
        {
            key = false;
        }
        else
        {
            key = true;
        }
    }
    else if (backpack.at(item) == 2)
    {
        healthPotQuant = healthPotQuant - 1;
        if (healthPotQuant < 1)
        {
            healthPotion = false;
        }
        else
        {
            healthPotion = true;
        }
    }
    else
    {
        trapPotQuant = trapPotQuant - 1;
        if (trapPotQuant < 1)
        {
            trapPotion = false;
        }
        else
        {
            trapPotion = true;
        }
    }
}


//get item and return item
int Inventory::getItem(int itemNumber)
{
    return backpack.at(itemNumber);
}


//remove item chosen
void Inventory::removeItem(int itemNumber)
{
    backpack.erase(backpack.begin() + (itemNumber));
}


//check if full
bool Inventory::isFull()
{
    if (backpack.size() == 4)
    {
        return true;
    }
    else
        return false;
}



//displays backpack
void Inventory::displayBackpack()
{
    int number = 1;
    vector<int> temp = backpack;
    string currentItem;
    
    cout << "The items in your backpack currently are:" << endl;
    
    while (temp.size() != 0)
    {
        if (temp.front() == 1)
        {
            currentItem = "Key";
        }
        else if (temp.front() == 2)
        {
            currentItem = "Health Potion";
        }
        else if (temp.front() == 3)
        {
            currentItem = "Trap Potion";
        }
        
        cout << number << ". " << currentItem << endl;
        number++;
        temp.erase(temp.begin());
    }
}


//bool if key
bool Inventory::hasKey()
{
    return key;
}


//bool for health potion
bool Inventory::hasHealthPotion()
{
    return healthPotion;
}


//bool for trap potion
bool Inventory::hasTrapPotion()
{
    return trapPotion;
}


//return health potion position
int Inventory::getHealthPos()
{
    if (backpack.at(0) == 2)
    {
        return 0;
    }
    else if (backpack.at(1) == 2)
    {
        return 1;
    }
    else if (backpack.at(2) == 2)
    {
        return 2;
    }
    else
        return 3;
}


//returns position of key
int Inventory::getKeyPos()
{
    if (backpack.at(0) == 1)
    {
        return 0;
    }
    else if (backpack.at(1) == 1)
    {
        return 1;
    }
    else if (backpack.at(2) == 1)
    {
        return 2;
    }
    else
        return 3;
}


//return position of trap potion
int Inventory::getTrapPotPos()
{
    if (backpack.at(0) == 3)
    {
        return 0;
    }
    else if (backpack.at(1) == 3)
    {
        return 1;
    }
    else if (backpack.at(2) == 3)
    {
        return 2;
    }
    else
        return 3;
}


//return keyQuant 
int Inventory::getKeyQuant()
{
    return keyQuant;
}


//returns healthPotQuant 
int Inventory::getHealthPotQuant()
{
    return healthPotQuant;
}


//returns trapPotQuant
int Inventory::getTrapPotQuant()
{
    return trapPotQuant;
}
