/***********************************
**Author: Pierre Saladino
**Description: menu header file
**********************************/

#ifndef FUNCTIONS_HPP
#define FUNCTIONS_HPP
#include "Space.hpp"
#include "Inventory.hpp"
#include "User.hpp"
#include <stdio.h>

int startLocation();
int getDirection(Space *l);
void setDirections(Space *l, int *currentLocation, int *up, int *, int *, int *);
void printBoard();
void cubeRun(Space *l2, Inventory *b2, User *u);
void runGame();
bool playAgain();



#endif
