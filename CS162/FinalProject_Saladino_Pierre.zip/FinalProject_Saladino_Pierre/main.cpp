/***********************************
**Author: Pierre Saladino
**Description: main executable file
**********************************/
#include "Menu.hpp"
#include <iostream>
using namespace std;


//display introduction
void intro()
{
    cout << "\n**********Welcome to the Revolving Door!**********\n" << endl;
    cout << "You wake up in a maze of doors and need to fins a way out!" << endl;
    cout << "\nThe only item you have with you is a backpack that can carry 10 items" << endl;
    cout << "You have 15 moves to find the key to escape!"<< endl;
    cout << "Otherwise the building will collapse and kill you!" << endl;
    cout << "Traps will hurt your health, so avoid them! " << endl;
    cout << "Look for potions to replenish back!" << endl;    	 	  		
    
}


//display instructions 
void description()
{
    cout  << "\nEach door is assigned a number, find a pattern to escape quickly!\n" << endl;
    cout << "Press enter to continue...";
    cin.ignore();
}


int main() {
    
    do{
    intro();
    description();
    runGame();
    }while(playAgain() == true);
    
    cout << endl << "The game has ended!" << endl;
    return 0;
}
