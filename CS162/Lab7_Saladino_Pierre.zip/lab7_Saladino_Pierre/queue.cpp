/**************************************************
**Author: Pierre Saladino
**Description: Queue implementation file 
**************************************************/

#include "Queue.hpp"
#include <iostream>
#include <memory>
//constructor
Queue::Queue()
{
head = nullptr;
back = nullptr;
}

//adds int val, returns nothing 
void Queue::addBack(int valin)
{
	if (isEmpty())
	{
	head = new QueueNode(valin, head, head);
	back = head;
	back -> Next = head;
	}

	else if (isFull())
	{
	back -> Next = new QueueNode(valin, head, back);
	back = back -> Next; 
	}

	else
	{
	back = back -> Next;
	back -> val = valin;
	}

}
//displays front node, returns head
int Queue::getFront()
{
	if (isEmpty())
	{
	std::cout << "Queue Empty \n";
	return -1;//print que empty  
	}
	
	else
	{
	return head -> val;
	}
}
//deletes the head, returns 0 if queue is not empty 
int Queue::removeFront()
{
	if (isEmpty())
	{
	std::cout << "Queue Empty \n";
	return -1;
	}

	else
	{
	head -> val = -1;
	head = head -> Next;
	return 0;
	}

}
//displays current queue
void Queue::printQueue()
{
	if(!isEmpty())
	{
	std::cout << "Current Que is: ";
	QueueNode *traverse = head;//traverses through que 
	std::cout << traverse -> val << " ";
	
		while(traverse != back)
		{
		traverse = traverse -> Next;
		std::cout << traverse -> val << " ";
		}
	std::cout << std::endl;    
	}

	else 
	{
	std::cout << "Queue is empty \n"; 
	}
}

//checks if queue is empty, returns true if it is
bool Queue::isEmpty()
{
	if (head == nullptr)//if head is empty
	{
	return true;
	}
	
	else if (head -> val == -1 && back -> val == -1)
	{
	return true;
	} 
	
	else
	{
	return false;
	}
}
//checks queue if not empty
bool Queue::isFull()
{
QueueNode *temp;
temp = back -> Next;

	if(temp -> val == -1)
	{
	return false;
	}  

	else
	{
	return true;
	}
}
//destructor
Queue::~Queue()
{

QueueNode *created = head;
	while(created != nullptr)
	{
	head = head -> Next;
	created -> Next = nullptr;
	delete created; 
	created = head;	
	}

}






