/****************************************
**Author: Pierre Saladino
**Description: Main exectutable file. includes
**main menu 
****************************************/
#include "Queue.hpp"
#include <unistd.h>
#include <iostream>
using namespace std;


//displays menu
void displayMenu()
{
    int choice = 0;
    int valin;
    Queue clist;//creates nodelist objects of doublylinkedlist class 
    
    cout << endl << "*************Circular Linked List Program************" << endl << endl;
    

    while(choice != 5)
    {
        cout << "Please select an option below:" << endl;
        cout << "1: Enter a value to be added to the back of the queue." << endl;
        cout << "2: Display the first node (front) value." << endl;
        cout << "3: Remove the first node (front) value." << endl;
        cout << "4: Display the queue contents." << endl;
        cout << "5: Exit the program." << endl;
        
        cin >> choice;
            
    	//if input is not valid display menu 
        while (choice < 1 || choice > 5)
        {
            cout << "\nInvalid input. Please try again." << endl;
            cin.clear();
            cin.ignore();
            displayMenu();
        }

        switch (choice)
        {
            case 1:
                cout << "Please enter the value you would like to add: ";
                cin >> valin;
                cin.clear();
                cin.ignore();
                while (valin < 1)
                {
                    cout << "Enter an integer greater than 0. Please try again: ";
                    cin >> valin;
                    cin.clear();
                    cin.ignore();
                }
                cout << endl;
                clist.addBack(valin);//adds int
                break;
            case 2:
		if(clist.getFront() != -1)//-1 returns error message
		{
		cout << "Display the first node (front) value: ";
		cout << clist.getFront() << "\n" << endl; //displays front node
		}
                break;
            case 3:
		if(clist.removeFront() != -1)//removes front node
		{
		cout << "Removed the first node (front) value ";
		cout << "\n" << endl;
		}
                break;
            case 4:
		clist.printQueue();//displays queue
		cout << "\n" << endl;
                break;
            case 5:
		cout << "Program Ended. Goodbye" << endl;
		exit(0);
		
        }
    }
}

int main()
{
displayMenu();//starts program 
return 0;
}
