/**************************************************
**Author: Pierre Saladino
**Description: Queue class
**************************************************/


#ifndef QUEUE_HPP
#define QUEUE_HPP
//queue class
class Queue
{	//struct name per req
     struct QueueNode
     {	//member vars per req
	int val;
	QueueNode *Next;
	QueueNode *Prev;
	
	QueueNode(int val1, QueueNode *Next1 = nullptr, QueueNode *Prev1 = nullptr)
	{
	val = val1;
	Next = Next1;
	Prev = Prev1;
	}
     };
//pointers to queue node objects
QueueNode *head;
QueueNode *back;

public:

Queue();
void addBack(int valin);
int getFront();
int removeFront();
void printQueue();
bool isEmpty();
bool isFull();
~Queue();

};
#endif
