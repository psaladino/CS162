/******************************************
**Author: Pierre Saladino
**Description: Penguin class, inherits from Animal class 
**
*******************************************/

#ifndef PENGUIN_HPP
#define PENGUIN_HPP 
#include "Animal.hpp"
class Penguin : public Animal
{
public:
	Penguin();
	void penguinage();
	bool bornBaby();

};
#endif
