/******************************************
**Author: Pierre Saladino
**Description: zoo class 
**
*******************************************/
#ifndef ZOO_HPP
#define ZOO_HPP
#include "Penguin.hpp"
#include "Tiger.hpp"
#include "Turtle.hpp"

class Zoo
{
public:
	//  Default constructor
	Zoo();

	double bankBalance;
	
	double startZoo(int tigers, int penguins, int turtles);

	void sickness();

	int boom();

	
	void bornbaby();


	int printProfit();


	double foodCostADay();

	void ageADay(); 	


	int buyAnAdultAnimal();
	

	~Zoo();
private:

	//adds animals in the zoo if baby(ies) are born 
	void addTiger();
	void addPenguin();
	void addTurtle();

	//kill an animal from zoo at random
	void killATiger(int index);
	void killAPenguin(int index);
	void killATurtle(int index);
	//pointer to an array 
	Tiger* tiger;
	Penguin* penguin;
	Turtle* turtle;
	int tiger_size, penguin_size, turtle_size;
	int tiger_length, penguin_length, turtle_length;
};
#endif
