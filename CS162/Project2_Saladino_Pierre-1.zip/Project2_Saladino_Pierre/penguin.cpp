/******************************************
**Author: Pierre Saladino
**Description: Penguin implementation file for penguin class 
**
*******************************************/

#include "Penguin.hpp"


//penguin constructor inherited from animal class 
Penguin::Penguin() :Animal(0, 1000, 0, 10, 0)
{
}
//sets penguin age
void Penguin::penguinage()
{
	setAge(this->getAge() + 1); // increse one day in age
}
//if age is > 3 baby is born if random event is chosen
bool Penguin::bornBaby()
{
	if (getAge() >= 3)
	{
		setNumberOfBabies(getNumberOfBabies() + 5);
		return true;
	}
	return false;
}




