/******************************************
**Author: Pierre Saladino
**Description: Implementation file for animal.hpp
**constructors in the animal class that will be inherited by other classes
**  
*******************************************/

#include "Animal.hpp"
//initializing variables
Animal::Animal()
{
	this->age = 0;
	this->numberOfBabies = 0;
	this->cost = 0;
	this->baseFoodCost = 0;
	this->payoff = 0;
}
//animal function takes age, cost, babies, food, payoff
Animal::Animal(int age, double cost, int numberOfBabies, double baseFoodCost, double payoff)
{
	this->age = age;
	this->numberOfBabies = numberOfBabies;
	this->cost = cost;
	this->baseFoodCost = baseFoodCost;
	this->payoff = payoff;
}
//setter functions 
void Animal::setAge(int age)
{
	this->age = age;
}

void Animal::setCost(double cost)
{
	this->cost = cost;
}

void Animal::setNumberOfBabies(int numberOfBabies)
{
	this->numberOfBabies = numberOfBabies;
}

void Animal::setBaseFoodCost(double baseFoodCost)
{
	this->baseFoodCost = baseFoodCost;
}

void Animal::setpayoff(int payoff)
{
	this->payoff = payoff;
}
//getter functions, returns variables of int and double
int Animal::getAge()
{
	return age;
}

double Animal::getCost()
{
	return cost;
}

int Animal::getNumberOfBabies()
{
	return this->numberOfBabies;
}

double Animal::getBaseFoodCost()
{
	return this->baseFoodCost;
}

int Animal::getPayoff()
{
	return this->payoff;
}
