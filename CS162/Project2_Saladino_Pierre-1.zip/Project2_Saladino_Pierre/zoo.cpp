/******************************************
**Author: Pierre Saladino
**Description: zoo implementation file 
**
*******************************************/

#include "Zoo.hpp"


//zoo function creates an array for each animal class and sets them to size 10  
Zoo::Zoo()
{
	tiger_size = penguin_size = turtle_size = 10;
	
	tiger = new Tiger[tiger_size];
	penguin = new Penguin[penguin_size];
	turtle = new Turtle[turtle_size];
}
//the following add functions add a baby animal, sets their age to 0
//if the size becomes greater than allocated size, the array doubles 
void Zoo::addTiger()
{
int i = tiger_length + 1;
this->tiger[i].setAge(0);
this->tiger_length++;
if (this->tiger_length > tiger_size)
{
tiger_size += (tiger_size * 2);  
}

}

void Zoo::addPenguin()
{
int i = penguin_length + 1;
this->penguin[i].setAge(0);
this->penguin_length++;
if (this->penguin_length > penguin_size)
{
penguin_size += (penguin_size * 2);  
}
}

void Zoo::addTurtle()
{
int i = turtle_length + 1;
this->turtle[i].setAge(0);
this->turtle_length++;
if (this->turtle_length > turtle_size)
{
turtle_size += (turtle_size * 2);  
}
}
//the kill function kills an animal at random based on event, then decreases size said animal  
void Zoo::killATiger(int index)

{
	if (index != this->tiger_length - 1)
	{
		for (int i = index; i < this->tiger_length - 1; i++)
		{
			this->tiger[i] = this->tiger[i + 1];
		}
	}
	this->tiger_length--;
}

void Zoo::killAPenguin(int index)
{
	if (index != this->penguin_length - 1)
	{
		for (int i = index; i < this->penguin_length - 1; i++)
		{
			this->penguin[i] = this->penguin[i + 1];
		}
	}
	this->penguin_length--;
}

void Zoo::killATurtle(int index)
{
	if (index != this->turtle_length - 1)
	{
		for (int i = index; i < this->turtle_length - 1; i++)
		{
			this->turtle[i] = this->turtle[i + 1];
		}
	}
	this->turtle_length--;
}
//starts zoo from purchasing animals and setting their age to 1, returns cost and subtracts from the bank
double Zoo::startZoo(int tigers, int penguins, int turtles)
{
	double cost = 0;
	this->tiger_length = tigers;
	this->penguin_length = penguins;
	this->turtle_length = turtles;
	cost += (this->tiger[0].getCost()) * tigers;
	cost += (this->penguin[0].getCost()) * penguins;
	cost += (this->turtle[0].getCost()) * turtles;
	// set all buyed animal age is 1
	for (int i = 0; i < this->tiger_length; i++)
	{
		this->tiger[i].setAge(1);
	}
	for (int i = 0; i < this->penguin_length; i++)
	{
		this->penguin[i].setAge(1);
	}
	for (int i = 0; i < this->turtle_length; i++)
	{
		this->turtle[i].setAge(1);
	}
	return cost;
}
//function to pick a random animal to get sick 
void Zoo::sickness()
{
	srand(time(NULL));
	switch (rand() % 3)
	{
	case 0:
		if (this->tiger_length > 0)
		{
			killATiger(rand() % this->tiger_length); // kill a random tiger
			cout << "A Tiger has died due to sickness\n";
		}
		break;
	case 1:
		if (this->penguin_length > 0)
		{
			killAPenguin(rand() % this->penguin_length); // kill a random penguin
			cout << "A Penguin has died due to sickness\n";
		}
		break;
	case 2:
		if (this->turtle_length > 0)
		{
			killATurtle(rand() % this->turtle_length); // kill a random turtle
			cout << "A Turtle has died due to sickness\n";
		}
		break;
	}
}
//this function from random generates a bonus for each tiget between 250-500
int Zoo::boom()
{
int bonus = 0;
	for (int i = 0; i < this->tiger_length; i++)
	{
	bonus = this->tiger[i].getBonus();
	}
int bonustotal = 0;
bonustotal = this->tiger_length * bonus;
cout << "A BOOM in zoo attendance! each tiger get a bonus payoff of " << bonus << '\n' ;
cout << "The total bonus was " << bonustotal << endl;
return bonustotal;
}
//picks an animal type at random and checks their age if age >= 3
//they will have a baby
void Zoo::bornbaby()
{

	srand(time(NULL));
	switch (rand() % 3)
	{
	case 0:
	for (int i = 0; i < this->tiger_length; i++)
	{
		if (this->tiger[i].bornBaby())
		{
			this->addTiger();
			cout << "Tiger gave birth to a baby Tiger\n";
			return;
		}
	}
	break;
 
	case 1:
	for (int i = 0; i < this->penguin_length; i++)
	{
		if (this->penguin[i].bornBaby())
		{
			for (int j = 0; j < 5; j++)
			{
				this->addPenguin();
			}
			cout << "Penguin gave birth to 5 baby Penguins\n";
			return;
		}
	}
	break;
	case 2: 
	for (int i = 0; i < this->turtle_length; i++)
	{
		if (this->turtle[i].bornBaby())
		{
			for (int j = 0; j < 10; j++)
			{
				this->addTurtle();
			}
			cout << "Turtle gave birth to 10 baby Turtles\n";
			return;
		}
	}
	
	break;
	}
	cout << "There are not any adult animals to give birth at this time\n";
}
//profit function for each iteration "day" returns total and subtracts from bank
int Zoo::printProfit()
{
int payofftotal = 0;
	
	int tigerpay = this->tiger_length * 2000;  
	
	cout << "Tiger No. " << this->tiger_length << " Profit: " << tigerpay << endl;
	payofftotal += tigerpay;
	
	int penguinpay = this->penguin_length * 100; 
	cout << "penguin No. " << this->penguin_length << " Profit: " << penguinpay << endl;
	payofftotal += penguinpay;

	int turtlepay = this->turtle_length * 5; 
	cout << "Turtle No. " << this->turtle_length << " Profit: " << turtlepay << endl;
	payofftotal += turtlepay;

return payofftotal;
}

//calculate food cost of all animals and returns cost and subtracts from bank each day
double Zoo::foodCostADay()
{
	double sum = 0;
	for (int i = 0; i < this->tiger_length; i++)
	{
		sum += this->tiger[i].getBaseFoodCost();
	}
	for (int i = 0; i < this->penguin_length; i++)
	{
		sum += this->penguin[i].getBaseFoodCost();
	}
	for (int i = 0; i < this->turtle_length; i++)
	{
		sum += this->turtle[i].getBaseFoodCost();
	}
	return sum;
}
//buys an adult animal if random event is chosen
//then sets age of that animal to 3 and adds it to the array
int Zoo::buyAnAdultAnimal()
{
	int nothingchoice = 0;
	int type = 0;
	int cost = 0;
	cout << "NOTHING HAPPENED!" << endl;
	cout << "Would you like to buy a new animal? 1. Yes 2. No " <<  endl;
	cin >> nothingchoice;
	while (!(nothingchoice >= 1 && nothingchoice <= 2))
	{
	cin.clear();
	cin.ignore();
	cout << "You must enter either 1 or 2 " << endl;
	cin >> nothingchoice;
	} 
	
	if (nothingchoice == 1)
	{
	cout << "Please enter 0 for tiger, 1 for penguin, and 2 for turtle " << endl;  
	cin >> type;
	while (!(type >= 0 && type <= 3))
	{
	cin.clear();
	cin.ignore();
	cout << "Please enter 0 for tiger, 1 for penguin, and 2 for turtle " << endl;  
	cin >> type;
	} 
	switch(type)
	{
	case 0:
	{
	cout << "****************A 3 year old tiger is added!" << endl; 
	int i = tiger_length + 1;	
	this->tiger[i].setAge(3);
	tiger_length++;
	cost = 10000;
	}
	break;

	case 1:
	{
	cout << "******************A 3 year old penguin is added!" << endl;
	int i = penguin_length + 1;	
	this->penguin[i].setAge(3);
	penguin_length++;
	cost = 1000;
	}
	break;
	
	case 2:
	{
	cout << "*****************A 3 year old turtle is added!" << endl;
	int i = turtle_length + 1;	
	this->turtle[i].setAge(3);
	turtle_length++;
	cost = 100;
	}
	break;

	}
	
	}

	return cost;
}
//adds age for every iteration of the game while its kept playing
void Zoo::ageADay()
{
	
	for (int i = 0; i < this->tiger_length; i++)
	{
	this->tiger[i].tigerage();
	}
	for (int i = 0; i < this->penguin_length; i++)
	{
	this->penguin[i].penguinage();
	}
	for (int i = 0; i < this->turtle_length; i++)
	{
	this->turtle[i].turtleage();
	}
	
}
//destructor of the pointers used in each animal class
Zoo::~Zoo()
{
delete [] tiger;
delete [] penguin;
delete [] turtle;
tiger = NULL;
penguin = NULL;
turtle = NULL;
}















