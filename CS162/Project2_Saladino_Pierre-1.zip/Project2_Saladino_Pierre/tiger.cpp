/******************************************
**Author: Pierre Saladino
**Description: Tiger implementation file 
**
*******************************************/

#include "Tiger.hpp"
//inherits from animal class 
Tiger::Tiger() :Animal(0, 10000, 0, 10 * 5, 0)
{
}
//sets tiger age bought to 1
void Tiger::tigerage()
{
	setAge(this->getAge() + 1); // increse one day in age
}
//gets bonus between 250 - 500
int Tiger::getBonus()
{
int bonus;
	srand(time(NULL)); //use srand to get diffrent number on every rand function call
	 bonus = (rand() % 250 + 250); 
return bonus;
}
//checks for age if a baby can be born
bool Tiger::bornBaby()
{
	if (getAge() >= 3)
	{
		setNumberOfBabies(getNumberOfBabies() + 1);
		return true;
	}
	return false;
}




