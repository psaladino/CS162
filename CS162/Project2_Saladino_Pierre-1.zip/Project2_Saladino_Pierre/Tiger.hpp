/******************************************
**Author: Pierre Saladino
**Description: Tiger class, inherits from Animal class 
**
*******************************************/

#ifndef TIGER_HPP
#define TIGER_HPP 
#include <time.h>
#include "Animal.hpp"
class Tiger : public Animal
{
public:
	Tiger();
	void tigerage();
	int getBonus();
	bool bornBaby();

};
#endif
