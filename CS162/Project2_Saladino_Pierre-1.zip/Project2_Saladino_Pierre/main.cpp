/******************************************
**Author: Pierre Saladino
**Description: main file
**
*******************************************/
#include <iostream>
#include <string>
#include "Zoo.hpp"

using namespace std;

//  Gets user input for number of animals to start game with
int getInput(string animal, int cost)
{
    int choice = 0;
    
    cout << "Enter Number (1 or 2) of " << animal << " you would like to buy for $" << cost << " each: ";
    cin >> choice;
    while (!(choice >= 1 && choice <= 2))
    {
        cin.clear();
        cin.ignore();
        cout << "You must buy either 1 or 2 " << animal << " to start the game. Please try again: ";
        cin >> choice;
    }
    return choice;
}
//menu for game
void gameInstruction()
{
    int choice = 0;
    cin.clear();
    cin.ignore();
    cout << endl << "Do you want to continue the game?\n1. Yes\n2. No\n ";
    cin >> choice;
    while (!(choice >= 1 && choice <= 2))
    {
        cin.clear();
        cin.ignore();
        cout << "Please enter 1 to continue the game or 2 to quit: ";
      cin >> choice;
    }
    if (choice == 2)
        exit(0);
}
//displays starting balance
void displayBalance(double bankBalance)
{
    cout << "Starting balance: " << bankBalance << endl;
}
//main function for looping per contiue
int main()
{
    int bankBalance = 100000;
    int bonustotal = 0;	
    int tigers, penguins, turtles, payofftotal, foodcost, buycost, cost;
    Zoo zoo;
    
    srand(time(NULL));
    displayBalance(bankBalance);
    tigers = getInput("Tigers", 10000);
    penguins = getInput("Penguins", 1000);
    turtles = getInput("Turtles", 100);
    
    buycost = zoo.startZoo(tigers, penguins, turtles);
    bankBalance -= buycost;  
    cout << "Your bank Balance is: " << bankBalance << endl;
    while (bankBalance > 0)
    {
        
        gameInstruction();
        foodcost = zoo.foodCostADay();
        cout << "Your bank Balance is: " << bankBalance << endl;
        switch (rand()%4)
        {
            case 0:
                zoo.sickness();
                break;
            case 1:
                bonustotal = zoo.boom();
                break;
            case 2:
                zoo.bornbaby();
                break;
	    case 3:		
		cost = zoo.buyAnAdultAnimal(); 
		break;
	}
	//subtracts from bank and adds payoff
        payofftotal = zoo.printProfit();
        bankBalance += payofftotal;
	bankBalance -= foodcost;
	bankBalance += bonustotal; 
	bankBalance -= cost; 
	zoo.ageADay();
	cout << "Your pay off total is " << payofftotal << endl; 
	cout << "The food cost for the day is " << foodcost << endl;
	cout << "Your bank Balance is: " << bankBalance << endl;
    }
    return 0;
}
