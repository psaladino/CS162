/******************************************
**Author: Pierre Saladino
**Description: Turtle Class 
**
*******************************************/

#ifndef TURTLE_HPP
#define TURTLE_HPP 
#include <time.h>
#include "Animal.hpp"
class Turtle : public Animal
{
public:
	public:
	Turtle();
	void turtleage();
	bool bornBaby();

};
#endif
