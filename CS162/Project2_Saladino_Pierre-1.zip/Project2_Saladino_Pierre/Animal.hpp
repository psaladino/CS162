/******************************************
**Author: Pierre Saladino
**Description: Animal class that will be inherited to 
**other animals classes
*******************************************/

#ifndef ANIMAL_HPP
#define ANIMAL_HPP
#include<iostream> 
using namespace std;
class Animal
{
public:

	//default constructors	
	Animal();
	Animal(int age, double cost, int numberOfBabies, double baseFoodCost, double payoff);

	//setters
	void setAge(int age);
	void setCost(double cost);
	void setNumberOfBabies(int numberOfBabies);
	void setBaseFoodCost(double baseFoodCost);
	void setpayoff(int payoff);

	//gettors
	int getAge();
	double getCost();
	int getNumberOfBabies();
	double getBaseFoodCost();
	int getPayoff();


private:

	int age;
	double cost;
	int numberOfBabies;
	double baseFoodCost;
	int payoff;
};
#endif
