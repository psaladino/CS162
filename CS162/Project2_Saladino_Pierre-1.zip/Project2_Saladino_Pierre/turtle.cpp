/******************************************
**Author: Pierre Saladino
**Description: Turtle implementation file 
**
*******************************************/

#include "Turtle.hpp"


//turtle constructor inherits from animal class
Turtle::Turtle() :Animal(0, 100, 0, 5, 0)
{
}
//sets turtle age bought to 1
void Turtle::turtleage()
{
	setAge(this->getAge() + 1); // increse one day in age
}
//checks age for nbaby
bool Turtle::bornBaby()
{
	if (getAge() >= 3)
	{
		setNumberOfBabies(getNumberOfBabies() + 10);
		return true;
	}
	return false;
}




