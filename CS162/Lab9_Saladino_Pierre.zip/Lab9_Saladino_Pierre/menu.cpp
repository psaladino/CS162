/********************************************
**Author: Pierre Saladino
**Description: menu implementation file
*******************************************/
#include "menu.hpp"
#include "queue.hpp"
#include "palindrome.hpp"
#include <iostream>
using namespace std;

//displays title, returtns nothing
void titleDisplay()
{
    cout << "*** Linear Data Structures Program ***" << endl << endl;
}
//displays menu 
void mainMenu()
{
    int choice;
    
    cout << "---Main Menu---: " << endl;
    cout << "1) Simulate the buffer." << endl;
    cout << "2) Create a palindrome." << endl;
    cout << "3) Exit program." << endl;
    cout << "Enter a choice: ";
    cin.clear();
    cin >> choice;
    
    if (choice != 1 && choice != 2 && choice != 3)
    {
        cin.clear();
        cin.ignore();
        cout << "Selection invalid. Please try again: ";
        cin >> choice;
    }
    else if (choice == 1)
    {
        queueContainer();//simulates buffer
    }
    else if (choice == 2)
    {
        palindrome();//creates palindrome
    }
    else if (choice == 3)
    {
        exit(0);//exits program
    }
    mainMenu();//displayes menu 
}

//prompts user for number of rounds simulated, returns int
int mainMenuRounds()
{
    int rounds;
    
    cout << "Please enter the number of rounds to be simulated: ";
    cin.clear();
    cin >> rounds;
    while (rounds <= 0 || rounds > 1000)
    {
        cin.clear();
        cin.ignore();
        cout << "Selection invalid. Please try again: ";
        cin >> rounds;
    }
    return rounds;
}

//promts user for percentage, returns double 
double mainMenuPush()
{
    double pushChance;
    
    cout << "Please enter the percentage chance to put a randomly generated number at the end of the buffer: ";
    cin.clear();
    cin >> pushChance;
    while (pushChance < 0 || pushChance > 100)
    {
        cin.clear();
        cin.ignore();
        cout << "Selection invalid. Please try again: ";
        cin >> pushChance;
    }
    return pushChance;
}

//promts user for percentage, returns double
double mainMenuPop()
{
    double popChance;
    
    cout << "Please enter the percentage chance to take out a randomly generated number at the front of the buffer: ";
    cin.clear();
    cin >> popChance;
    while (popChance < 0 || popChance > 100)
    {
        cin.clear();
        cin.ignore();
        cout << "Selection invalid. Please try again: ";
        cin >> popChance;
    }
    return popChance;
}
