/********************************************
**Author: Pierre Saladino
**Description: menu header file
*******************************************/
#ifndef MENU_HPP
#define MENU_HPP

#include <stdio.h>


void titleDisplay();
void mainMenu();
int mainMenuRounds();
double mainMenuPush();
double mainMenuPop();



#endif
