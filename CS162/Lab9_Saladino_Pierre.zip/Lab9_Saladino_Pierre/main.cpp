/********************************************
**Author: Pierre Saladino
**Description: main implementation file
*******************************************/
#include "menu.hpp"
#include "queue.hpp"
#include "palindrome.hpp"
#include <iostream>


int main()
{    
    //display title and receive inputs
    titleDisplay();
    mainMenu();
    
    return 0;
}
