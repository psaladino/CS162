/********************************************
**Author: Pierre Saladino
**Description: palindrome header file
*******************************************/
#ifndef PALINDROME_HPP
#define PALINDROME_HPP

#include <stdio.h>
#include<cstring>

void palindrome();
void reverse(char *pali, int length);

#endif 
