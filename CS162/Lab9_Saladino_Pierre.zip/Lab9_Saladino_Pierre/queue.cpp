/********************************************
**Author: Pierre Saladino
**Description: queue implementation file
*******************************************/

#include "queue.hpp"
#include "menu.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <queue>
#include <list>
using namespace std;


//creates container from user input rounds and percentages
void queueContainer()
{
    int rounds, N, N2, pushStatus, popStatus;
    double pushChance, popChance;
    double avg = 0, avgPrev;
    queue<int, list<int>> que, queTemp;
    
    unsigned seed;
    seed = time(0);
    srand(seed);
    
    //receive variable inputs 
    rounds = mainMenuRounds();
    pushChance = mainMenuPush();
    popChance = mainMenuPop();
    
    for (int i = 0; i < rounds; i++)
    {
        pushStatus = 0;
        popStatus = 0;
        avgPrev = avg;
        
        N = rand() % 1000 + 1;
        
        N2 = rand() % 100 + 1;
        
        if (N2 <= pushChance)//if number is less than or equal to % add N to queue
        {
            que.push(N);
            pushStatus++;
        }
        
        N2 = rand() % 100 + 1;
        
        if (N2 <= popChance && !que.empty())//removes a number N from front of queue if N2 <= % 
        {
            que.pop();
            popStatus++;
        }
        
        queTemp = que;
        
        cout << endl << "Round " << (i + 1) << endl;
        
        if (pushStatus && popStatus)
        {
            cout << "Both push and pop have been triggered." << endl;
        }
        else if (pushStatus)
        {
            cout << "Only the push function has been triggered." << endl;
        }
        else if (popStatus)
        {
            cout << "Only the pop function has been triggered." << endl;
        }
        else
        {
            cout << "Neither the push nor pop function has been triggered." << endl;
        }
        
        cout << "Elements of the queue from the front are: ";
        while (!queTemp.empty())
        {
            cout << queTemp.front() << " ";
            queTemp.pop();
        }
        
        cout << endl;
        
        cout << "The length of the buffer after round " << (i + 1) << " is: " << que.size() << endl;
        
        avg =(avgPrev * i + que.size()) / (i + 1);
        cout << "The average of the buffer after round " << (i + 1) << " is: " << avg << endl;
    }
}
