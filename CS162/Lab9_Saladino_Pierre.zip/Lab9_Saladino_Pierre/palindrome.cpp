/********************************************
**Author: Pierre Saladino
**Description: palindrome implementation file
*******************************************/
#include "palindrome.hpp"
#include "menu.hpp"
#include "queue.hpp"
#include <string>
#include <iostream>
#include <stack>
#include <stdio.h>
using namespace std;

//prompts for string, displays palindrome  
void palindrome()
{
    char pali[100];
    int length;
    
    cout << "Enter a string that you would like to be displayed as a palindrome: ";
    cin.ignore();
    cin.getline(pali, 100);
    
    cout << "The string you entered displayed as a palindrome is: ";
    
    length = strlen(pali);
    cout << pali;
    
    reverse(pali, length);
    cout << pali;
    cout << endl << endl;
}
//reverses the string from stack
void reverse(char *pali, int length)
{
    stack<char> palin;
    
    for (int i = 0; i < length; i++)
    {
        palin.push(pali[i]);
    }
    for (int i = 0; i < length; i++)
    {
        pali[i] = palin.top();
        palin.pop();
    }
}
