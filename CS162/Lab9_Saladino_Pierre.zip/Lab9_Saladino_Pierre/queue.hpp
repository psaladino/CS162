/********************************************
**Author: Pierre Saladino
**Description: queue header file
*******************************************/
#ifndef queue_hpp
#define queue_hpp
#include <stdio.h>

void queueContainer();

#endif 
